package hillbillies.part2.listener;

public class DefaultTerrainChangeListener implements TerrainChangeListener {

	@Override
	public void notifyTerrainChanged(int x, int y, int z) {
		// do nothing
	}

}
