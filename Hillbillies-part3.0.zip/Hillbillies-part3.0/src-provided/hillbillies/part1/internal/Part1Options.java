package hillbillies.part1.internal;

import hillbillies.common.internal.options.HillbilliesOptions;

public class Part1Options extends HillbilliesOptions {
}
