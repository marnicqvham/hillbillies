package hillbillies.part1.internal.controller;

public class BaseActionExecutor {
	// This class has been moved to hillbillies.common.internal.controller,
	// and just remains here as a placeholder to overwrite the code from part 1.
}
