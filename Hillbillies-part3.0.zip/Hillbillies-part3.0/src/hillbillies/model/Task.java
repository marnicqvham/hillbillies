package hillbillies.model;


import be.kuleuven.cs.som.annotate.Basic;
import be.kuleuven.cs.som.annotate.Raw;
import hillbillies.Util.StatementTree;
import hillbillies.model.expression.Expression;
import hillbillies.model.statement.BreakStatement;
import hillbillies.model.statement.Statement;
import hillbillies.model.statement.WhileStatement;
import hillbillies.model.statement.action.ActionStatement;
import ogp.framework.util.ModelException;

import java.util.*;
import java.util.stream.Collectors;

/**
 * Created by robin on 2/05/16.
 */
public class Task {
    public final String name;
    private int priority;
    private Unit assignedUnit;
    public final Statement activity;
    public final int[] selectedCube;
    private Set<Scheduler> partof;
    private Stack<Statement> todo;
    private Map<String,Expression> variables;
    private double t;

    public Task(String name, int priority, Statement activity, int[] selectedCube){
        this.name = name;
        this.priority = priority;
        this.activity = activity;
        this.assignedUnit = null;
        this.selectedCube = selectedCube;
        this.partof = new HashSet<>();
        if(!breakSafety()){
            System.out.println("Invalid task");
            terminate();
        }
    }

    /**
     * @param dt
     * @return true if the task is complete, false if the task is still going.
     * @throws ModelException
     */
    public boolean execute(double dt) throws ModelException{
        t += dt + 0.001;
        do{
            if (todo.size() <= 0){
                return true;
            }
            try {
                if (executeNext()) {
                    break;
                }
            }catch (TaskException e){
                e.killTask();
                throw new ModelException(e.getMessage());
            }
            t -= 0.001;
        }while(t >= 0.001);
        return  false;
    }


    /**
     * @return true if the program needs to wait or stop.
     *          If the current statement is an action statement
     *          or if the program is done.
     * @throws TaskException
     */
    private boolean executeNext() throws TaskException{
        if (todo == null || assignedUnit == null){
            throw new TaskException("Cannot execute this task", this);
        }

        while(todo.peek()==null){
            todo.pop();
        }

        if (todo.isEmpty()){
            return true;
        }

        if(todo.peek().getClass().equals(BreakStatement.class)){
            breakWhile();
        }

        Statement current = todo.pop();
        List<Statement> newStatements = current.execute(this);
        Collections.reverse(newStatements);
        todo.addAll(0, newStatements);

        return current.getClass().getSuperclass().equals(ActionStatement.class);
    }

    private void breakWhile() throws TaskException {
        if (todo.stream().filter(s -> s.getClass().equals(WhileStatement.class)).collect(Collectors.toList()).size() >= 1)

        {
            while (!todo.peek().equals(WhileStatement.class)) {
                todo.pop();
            }
        }else {
            throw new TaskException("Break without while", this);
        }
    }

    public void assignUnit(Unit unit){
        this.variables = new HashMap<>();
        this.assignedUnit = unit;
        unit.assignTask(this);
        this.todo = new Stack();
        todo.add(activity);
    }

    public void failTask(){
        this.assignedUnit.assignTask(null);
        this.assignedUnit = null;
        this.priority--;
    }

    public int getPriority(){
        return priority;
    }

    public String getName(){
        return name;
    }

    public Unit getUnit(){
        return assignedUnit;
    }

    public World getWorld() {
        return getUnit().world;
    }

    /**
     * @return assignedUnit != null && !assignedUnit.isTerminated()
     */
    public boolean isExecuting(){
        return (assignedUnit != null && !assignedUnit.isTerminated());
    }

    public void addedToScheduler(Scheduler scheduler){
        partof.add(scheduler);
    }
    public void removedFromScheduler(Scheduler scheduler){
        partof.remove(scheduler);
    }
    public Set<Scheduler> getSchedulersForTask(){
        return partof;
    }

    public Map<String, Expression> getVariables(){
        return variables;
    }

    public Expression getVariable(String key){
        return variables.get(key);
    }

    /**
     * Terminate this task.
     *
     * @post   This task is terminated.
     *       | new.isTerminated()
     */
    public void terminate() {
        this.isTerminated = true;
        assignedUnit = null;
        partof = null;
        todo = null;
        variables = null;
    }

    /**
     * Return a boolean indicating whether or not this Unit
     * is terminated.
     */
    @Basic
    @Raw
    public boolean isTerminated() {
        return this.isTerminated;
    }

    /**
     * Variable registering whether this person is terminated.
     */

    private boolean isTerminated = false;

     public boolean breakSafety() {
         StatementTree statementTree = new StatementTree(activity);
         for (StatementTree.Node statement: statementTree.getBreakstatements()) {
             StatementTree.Node node = statement;
             while (!(node.getParent() == null)){
                 if (node.statement.getClass() == WhileStatement.class)
                     break;
                 node = node.getParent();
             }

         }
         return statementTree.getBreakstatements().size() == 0;
     }

}
