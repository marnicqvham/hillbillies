package hillbillies.model;

/**
 * Created by Robin on 22/02/2016.
 * GELUKKIGE VERJAARDAG ROBIN
 */
public class Orientations {
    static final double RIGHT = 0; 
    static final double RIGHT_DOWN = Math.PI/4; 
    static final double DOWN = Math.PI/2; 
    static final double LEFT_DOWN = 3*Math.PI/4;
    static final double LEFT = Math.PI; 
    static final double LEFT_UP = -3*Math.PI/4;
    static final double UP = 3*Math.PI/2; 
    static final double RIGHT_UP = -Math.PI/4; 
}
