package hillbillies.model;


/**
 * Created by Robin on 22/02/2016.
 * Attributes needs to be programmed total
 * GELUKKIGE VERJAARDAG ROBIN
 * Danku Marnicq
 */
public class Attributes {
    int weight, agility, strength, toughness;



    /**
     * Set the weight of this unit to the given weight.
     *
     * @param  weight
     *         The new weight for this unit.
     * @post   If the given weight is a valid weight for any unit,
     *         the weight of this new unit is equal to the given
     *         weight.
     *       | if (isValidweight(weight))
     *       |   then new.getweight() == weight
     */
    public void setWeight(int weight) {
        if (isValidWeight(weight)) {
            this.weight = weight;
        }
    }
    /**
     * Set the agility of this unit to the given agility.
     *
     * @param  agility
     *         The new agility for this unit.
     * @post   If the given agility is a valid agility for any unit,
     *         the agility of this new unit is equal to the given
     *         agility.
     *       | if (isValidagility(agility))
     *       |   then new.getagility() == agility
     */
    public void setAgility(int agility) {
        if (isValidAgility(agility)){
            this.agility = agility;
        }
    }
    /**
     * Set the strength of this unit to the given strength.
     *
     * @param  strength
     *         The new strength for this unit.
     * @post   If the given strength is a valid strength for any unit,
     *         the strength of this new unit is equal to the given
     *         strength.
     *       | if (isValidstrength(strength))
     *       |   then new.getstrength() == strength
     */
    public void setStrength(int strength) {
        if (isValidStrength(strength)){
            this.strength = strength;
        }
    }
    /**
     * Set the toughness of this unit  to the given toughness.
     *
     * @param toughness
     *         The new toughness for this unit .
     * @post   If the given toughness is a valid toughness for any unit ,
     *         the toughness of this new unit  is equal to the given
     *         toughness.
     *       | if (isValidtoughness(toughness))
     *       |   then new.gettoughness() == toughness
     */

    public void setToughness(int toughness) {
        if (isValidToughness(toughness)){
            this.toughness = toughness;
        }
    }
    /**
     * Return the weight of this unit.
     * @return the weight of this unit.
     */
     public int getWeight() {
        return weight;
    }
    /**
     * Return the agility of this unit.
     * @return the agility of this unit.
     */
    public int getAgility() {
        return agility;
    }
    /**
     * Return the strength of this unit.
     * @return the strength of this unit.
     */
     public int getStrength() {
        return strength;
    }
    /**
     * Return the toughness of this unit.
     * @return the toughness of this unit.
     */
     public int getToughness() {
        return toughness;
    }

    /**
     * Initialize this new unit with given weight, agility, strenght and agility.
     *
     * @param  weight, agility, strength, toughness
     *         The weight, agility, strenght and agility for this new unit.
     * @post   If the given weight, agility, strenght and agility is a valid weight, agility, strenght and agility for any unit,
     *         the weight, agility, strenght and agility of this new unit is equal to the given
     *         weight, agility, strenght and agility. Otherwise, the weight, agility, strenght and agility of this new unit is equal
     *         to .
     *       | if (isValid(weight, agility, strength, toughness))
     *       |   then new.get() == weight, agility, strength, toughness
     *       |   else new.get() == defaultvalue = 25
     */
    public Attributes(int weight, int agility, int strength, int toughness) {
        int defaultValue = 25;
        if (isValidInitialWeight(weight)){
            this.weight = weight;
        }else{
            this.weight = defaultValue;
        }

        if (isValidInitialAgility(agility)){
            this.agility = agility;
        }else{
            this.agility = defaultValue;
        }

        if (isValidInitialToughness(toughness)){
            this.toughness = toughness;
        }else{
            this.toughness = defaultValue;
        }

        if (isValidInitialStrength(strength)){
            this.strength = strength;
        }else{
            this.strength = defaultValue;
        }
    }
    /**
     * Check whether the given value is a valid value for
     * any unit.
     *
     * @param  value
     *         The value to check.
     * @return
     *       | result == 0 < value <= 200
    */
    private static boolean isVAlidValue(int value){
        return (0<value) && (value<=200);
    }

    /**
     * Check whether the given initialValue is a valid initialValue for
     * any unit.
     *
     * @param  initialValue
     *         The initialValue to check.
     * @return
     *       | result == 25 <= value <= 100
    */
    private static boolean isValidInitialValue(int initialValue){
        return (isVAlidValue(initialValue) && 25<=initialValue && initialValue<=100);
    }
    /**
     * Check whether the given weight is a valid weight for
     * any unit.
     *
     * @param  value
     *         The weight to check.
     * @return
     *       | result == (this.getStrength()+this.getAgility())/2) && isVAlidValue(value)
    */
    private boolean isValidWeight(int value){
        return (isVAlidValue(value) && (
                value>=(
                        (this.getStrength()+this.getAgility())/2)
                )
        );
    }
    /**
     * Check whether the given weight is a valid initialWeight for
     * any unit.
     *
     * @param  value
     *         The weight to check.
     * @return
     *       | result == isValidInitialValue(value)
    */
    private boolean isValidInitialWeight(int value){
        return isValidInitialValue(value) && isValidWeight(value);
    }

    /**
     * Check whether the given agility is a valid agility for
     * any unit.
     *
     * @param  value
     *         The agility to check.
     * @return
     *       | result == isVAlidValue(value)
    */
    private boolean isValidAgility(int value){
        return (isVAlidValue(value));
    }
    /**
     * Check whether the given agility is a valid initialAgility for
     * any unit.
     *
     * @param  value
     *         The agility to check.
     * @return
     *       | result == isValidInitialValue(value)
     */
    private boolean isValidInitialAgility(int value){
        return isValidInitialValue(value) && isValidAgility(value);
    }

    /**
     * Check whether the given strength is a valid strength for
     * any unit.
     *
     * @param  value
     *         The strength to check.
     * @return
     *       | result == isVAlidValue(value)
     */
    private boolean isValidStrength(int value){
        return (isVAlidValue(value));
    }
    /**
     * Check whether the given strength is a valid initialStrength for
     * any unit.
     *
     * @param  value
     *         The strength to check.
     * @return
     *       | result == isValidInitialValue(value)
     */
    private boolean isValidInitialStrength(int value){
        return isValidInitialValue(value) && isValidStrength(value);
    }

    /**
     * Check whether the given toughness is a valid toughness for
     * any unit.
     *
     * @param  value
     *         The toughness to check.
     * @return
     *       | result == isVAlidValue(value)
     */
    private boolean isValidToughness(int value){
        return (isVAlidValue(value));
    }
    /**
     * Check whether the given toughness is a valid initialToughness for
     * any unit.
     *
     * @param  value
     *         The toughness to check.
     * @return
     *       | result == isValidInitialValue(value)
     */
    private boolean isValidInitialToughness(int value){
        return isValidInitialValue(value) && isValidToughness(value);
    }



}