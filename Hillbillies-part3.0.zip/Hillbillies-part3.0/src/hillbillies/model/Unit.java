package hillbillies.model;

import be.kuleuven.cs.som.annotate.Basic;
import be.kuleuven.cs.som.annotate.Raw;
import hillbillies.Util.RndFinder;
import hillbillies.Util.Util;
import ogp.framework.util.ModelException;

import java.util.Random;
import java.util.regex.Pattern;

import static hillbillies.model.Job.Jobs.*;

/**
 * @invar  The faction of each Unit must be a valid faction for any
 *         Unit.
 *       | isValidFaction(getFaction())
 *
 *
 * @invar  The Name of each Unit must be a valid Name for any
 *         Unit.
 *       | isValidName(getName())
 *
 *
 * @invar  The position of each Unit must be a valid position for any
 *         Unit.
 *       | isValidPosition(getPosition())
 *
 *
 * @invar  The attributes of each Unit must be a valid attributes for any
 *         Unit.
 *       | isValidAttribute(getAttribute())
 *
 *
 * @invar  The job of each Unit must be a valid job for any
 *         Unit.
 *       | isValidJob(getJob())
 *
 *
 * @invar  The currenthitpoints of each unit must be valid hitpoints for any
 *         unit.
 *       | isValidCurrentHitPoints(getCurrentHitPoints())
 *
 *
 * @invar  The currentStaminaPoints of each Unit must be a valid currentStaminaPoints for any
 *         Unit.
 *       | isValidStaminaPoints(getStaminaPoints())
 *
 *
 * @invar  The world of each Unit must be a valid world for any
 *         Unit.
 *       | isValidWorld(getWorld())
 */



public class Unit {
	private String name;
	private Position position;
	private Position adjacentTargetPosition;
	private Path path;
	private Attributes attributes;
	private boolean defaultBehavior;
	private int currentHitPoints, currentStaminaPoints, experiencePoints;
	private double orientation = Math.PI/2;
    private boolean movingToAttack;
    private Unit target;
	private Position workTarget;
    private double currentSpeed;
	private Job job;
	public final World world;
	public final Faction faction;
	private WorldObject worldObject;
	private boolean movingToWork;
	private Task task;

	/**
	 * GELUKKIGE VERJAARDAG ROBIN
	 * @param name The name of this unit
	 * @param initialPosition The position of this unit when created
	 * @param weight 25 <= weight <= 100
	 * @param agility 25 <= agility <= 100
	 * @param strength 25 <= strength <= 100
	 * @param toughness 25 <= toughness <= 100
	 * @param enableDefaultBehavior state of default behavior
	 * @param world The wolrd of this unit
	 * @throws ModelException If isValidInitialAbility retruns false for an ability
	 */

	/**
	 * Initialize this new Name with given Name.
	 *
	 * @param  name
	 *         The Name for this new Name.
	 * @effect The Name of this new Name is set to
	 *         the given Name.
	 *       | this.setName(name)
	 */
	/**
	 * Initialize this new Faction with given faction.
	 *
	 * @param  faction
	 *         The faction for this new Faction.
	 * @post   If the given faction is a valid faction for any Faction,
	 *         the faction of this new Faction is equal to the given
	 *         faction. Otherwise, the faction of this new Faction is equal
	 *         to faction.
	 *       | if (isValid(faction))
	 *       |   then new.get() == faction
	 *       |   else new.get() == faction
	 */
	/**
	 * Initialize this new position with given initialPosition.
	 *
	 * @param  initialPosition
	 *         The position for this new position.
	 * @effect The position of this new position is set to
	 *         the given position.
	 *       | this.set(initialPosition)
	 */
	/**
	 * Initialize this new Attributes with given Weight, agility, strength, toughness.
	 *
	 * @param  weight
	 * @param  agility
	 * @param  strength
	 * @param  toughness
	 *         The Weight, agility, strength, toughness for this new Attributes.
	 * @post   If the given Weight, agility, strength, toughness is a valid Weight, agility, strength, toughness for any Attributes,
	 *         the Weight, agility, strength, toughness of this new Attributes is equal to the given
	 *         Weight, agility, strength, toughness. Otherwise, the Weight, agility, strength, toughness of this new Attributes is equal
	 *         to Defaultvalue.
	 *       | if (isValidInitalvalue(attribute))
	 *       |   then new.get() == attribute
	 *       |   else new.get() == DefaultValue
	 */
	/**
	 * Initialize this new Job with given wait.
	 *
	 * @effect The status of the job of this Unit is
	 *         set to wait.
	 *       | this.setjob(wait)
	 */
	/**
	 * Initialize this new defaultBehavior with given boolean.
	 *
	 * @param  enableDefaultBehavior
	 *         The boolean for this new defaultBehavior.
	 * @pre    The given boolean must be a valid boolean for any defaultBehavior.
	 *       | isValidDefaultBehaviour(boolean)
	 * @post   The boolean of this new defaultBehavior is equal to the given
	 *         boolean.
	 *       | new.getDefaultBehaviour() == enableDefaultBehavior
	 */
	/**
	 * Initialize this new world with given world.
	 *
	 * @param  world
	 *         The world for this new world.
	 * @effect The world of this new world is set to
	 *         the given world.
	 *       | this.setworld(world)
	 */



	public Unit(String name, int[] initialPosition, int weight, int agility, int strength, int toughness,
				boolean enableDefaultBehavior, World world, Faction faction) throws ModelException{
		this.faction = faction;
		setName(name);
		this.position = new Position(initialPosition, world);
		this.attributes = new Attributes(weight, agility, strength, toughness);
		job = new Job(this, wait);
		this.currentHitPoints = getMaxHitPoints();
		this.currentStaminaPoints = getMaxStaminaPoints();
		this.defaultBehavior = enableDefaultBehavior;
		this.world = world;
		world.addUnit(this);


	}

	public Unit(String name, Position initialPosition, int weight, int agility, int strength, int toughness,
				boolean enableDefaultBehavior, World world, Faction faction) throws ModelException {
		this(name, initialPosition.getPosAsInt(), weight, agility, strength, toughness, enableDefaultBehavior, world, faction);
	}

	protected void assignTask(Task task){
		this.task = task;
	}
	public Task getTask(){
		return task;
	}

	/**
	 * Check whether the given name is a valid name for
	 * any unit.
	 *
	 * @param  name
	 *         The name to check.
	 * @return
	 *       | result == Pattern.matches("[A-Z][a-zA-Z'\"]*", name)
	*/
    private static boolean isValidName(String name){
        return Pattern.matches("[A-Z][a-zA-Z'\"]*", name);
    }
	/**
     *
     * Return the Name of the unit
	 * @return The name of the unit
     */
	public String getName() {
		return this.name;
	}
	/**
	 * Return the faction of this unit.
	 * @return the faction of this unit.
	 */
	@Basic @Raw
	public Faction getFaction(){
		return this.faction;
	}
	/**
	 * Return the position of this unit.
	 * @return the position of this unit.
	 */
	@Basic @Raw
	public Position getPosition() {
		return position;
	}
	/**
	 * Set the name of this unit to the given name.
	 *
	 * @param  name
	 *         The new name for this unit.
	 * @post   The name of this new unit is equal to
	 *         the given name.
	 *       | new.getName() == name
	 * @throws ModelException
	 *         The given name is not a valid name for any
	 *         unit.
	 *       | ! isValidName(getName())
	 */
	@Raw
	public void setName(String name) throws ModelException{
        if (!isValidName(name)){
			throw new ModelException("Invalid name"); //defensive
		}else{this.name = name;}
	}

    /**
     *
     * return the weight of the unit
	 * @return the weight of the unit
     */
	public int getWeight() {
		if (isCarrying() != null)
			return this.attributes.getWeight() + isCarrying().getWeight() ;
		else
			return this.attributes.getWeight();
	}
	/**
	 * Set the weight of this unit to the given weight.
	 *
	 * @param  weight
	 *         The new weight for this unit.
	 * @post   If the given weight is a valid weight for any unit,
	 *         the weight of this new unit is equal to the given
	 *         weight.
	 *       | if (isValidWeight(weight))
	 *       |   then new.getWeight() == weight
	 */
	@Raw
	public void setWeight(int weight) {
		this.attributes.setWeight(weight);
	}
    /**
     *
     * return the agility of the unit
	 * @return the agility of the unit
     */
	public int getAgility() {
		return this.attributes.getAgility();
	}
	/**
	 * Set the agility of this unit to the given agility.
	 *
	 * @param  agility
	 *         The new agility for this unit.
	 * @post   If the given agility is a valid agility for any unit,
	 *         the agility of this new unit is equal to the given
	 *         agility.
	 *       | if (isValidAgility(agility))
	 *       |   then new.getAgility() == agility
	 */
	@Raw
	public void setAgility(int agility) {
        this.attributes.setAgility(agility);
	}
    /**
     *
     * return the Strength of the unit
	 * @return The strength of this unit
     */
	public int getStrength() {
		return this.attributes.getStrength();
	}
	/**
	 * Set the strenght of this unit to the given strenght.
	 *
	 * @param  strength
	 *         The new strenght for this unit.
	 * @post   If the given strenght is a valid strenght for any unit,
	 *         the strenght of this new unit is equal to the given
	 *         strenght.
	 *       | if (isValidStrength(strength))
	 *       |   then new.getStrength() == strength
	 */
	@Raw
	public void setStrength(int strength) {
        this.attributes.setStrength(strength);
	}
    /**
     *
     * return the toughness of the unit
	 * @return the toughness of this unit
     */
	public int getToughness() {
		return this.attributes.getToughness();
	}

	public void setToughness(int toughness) {
        this.attributes.setToughness(toughness);
	}

    /**
     *
     * return the maximum possible hitpoints of the unit
     * @return the max the maximum possible hitpoints of this unit
	 */
	public int getMaxHitPoints(){
		return (int)(200*((double)this.getWeight()/100)*((double)this.getToughness()/100)); // das mooi,
		// zever die 0 geeft gwn eerst casten naar double
    }
    /**
     *
     * return the maximum possible stamina points of the unit
	 * @return the maximum possible stamina points of the unit
     */
	public int getMaxStaminaPoints(){
        return (int)(200*((double)this.getWeight()/100)*((double)this.getToughness()/100));
    }

    /**
     *
     * return the current hitpoints of the unit
	 * @return the current hitpoints of the unit
     */
	public int getCurrentHitPonits(){
        return this.currentHitPoints;
    }
	/**
	 * Set the currentHitpoints of this unit to the given currentHitpoints.
	 *
	 * @param  hitPoints
	 *         The new currentHitpoints for this unit.
	 * @pre    The given currentHitpoints must be a valid currentHitpoints for any
	 *         unit.
	 *       | isValidHitPoints(hitPoints)
	 * @post   The currentHitpoints of this unit is equal to the given
	 *         currentHitpoints.
	 *       | new.getHitPoints() == hitPoints
	 */
	@Raw
	public void setCurrentHitPoints(int hitPoints){
		assert isValidHitpoints(hitPoints);
		this.currentHitPoints = hitPoints;
	}

    /**
     * return the current stamina points of the unit
	 * @return the current stamina points of the unit
     */

	public int getCurrentStaminaPonints(){
        return this.currentStaminaPoints;
    }
	/**
	 * Set the currentStaminaPoints of this unit to the given currentStaminaPoints.
	 *
	 * @param  staminaPoints
	 *         The new currentStaminaPoints for this unit.
	 * @pre    The given currentStaminaPoints must be a valid currentStaminaPoints for any
	 *         unit.
	 *       | isValidStaminaPoints(staminaPoints)
	 * @post   The currentStaminaPoints of this unit is equal to the given
	 *         currentStaminaPoints.
	 *       | new.getStaminaPoints() == staminaPoints
	 */
	@Raw
	public void setCurrentStaminaPoints(int staminaPoints){
		assert isValidStaminaPoints(staminaPoints);
		this.currentStaminaPoints = staminaPoints;
	}
	/**
	 * Check whether the given currentHitPoints is a valid currentHitPoints for
	 * any unit.
	 *
	 * @param  currentHitPoints
	 *         The currentHitpoints to check.
	 * @return
	 *       | result == (currentHitPoints > 0) && (currentHitPoints < this.getMaxHitPoints())
	*/
	private boolean isValidHitpoints(int currentHitPoints){
		return (currentHitPoints >= 0) && (currentHitPoints <= this.getMaxHitPoints());
	}

	/**
	 * Check whether the given currentStaminaPoints is a valid currentStaminaPoints for
	 * any unit.
	 *
	 * @param  currentStaminaPoints
	 *         The currentStaminaPoints to check.
	 * @return
	 *       | result == (currentStaminaPoints > 0) && (currentStaminaPoints < this.getMaxStaminaPoints())
	 */
	private boolean isValidStaminaPoints(int currentStaminaPoints){
		return (currentStaminaPoints > 0) && (currentStaminaPoints < this.getMaxStaminaPoints());
	}
	/**
	 * Return the orientation of this unit.
	 * @return the orientation of this unit.
	 */
	 @Basic @Raw
	 public double getOrientation(){
		return this.orientation;
	}
	/**
	 * Set the orientation of this unit to the given orientation.
	 *
	 * @param  orientation
	 *         The new orientation for this unit.
	 * @post   If the given orientation is a valid orientation for any unit,
	 *         the orientation of this new unit is equal to the given
	 *         orientation.
	 *       | if (isValidorientation(orientation))
	 *       |   then new.getorientation() == orientation
	 */
	@Raw
	private void setOrientation(double orientation) throws ModelException{
		if (!isValidOrientation(orientation)){
			throw new ModelException("Invalid orientation, the orientation has to be between or equal to 0 and 2PI");
		}
		this.orientation = orientation;
	}

	/**
	 * Check whether the given Orientation is a valid Orientation for
	 * any unit.
	 *
	 * @param  orientation
	 *         The Orientation to check.
	 * @return
	 *       | result == True if the orientation is between or equal to 0 and 2pi, else false.
	*/
	private boolean isValidOrientation(double orientation){
		return true;
	}

	/**
	 * Return the base speed of this unit.
	 * @return 1.5*(strength+agility)/(200*(weigth/100))
     */
	private double getBaseSpeed(){
		return 1.5*(
				(getStrength()+getAgility())/(
						200*((double)getWeight()/100)
						)
		);
	}

	/**
	 * Sets the job of this unit to sprinting
	 * if the stamina points are > 0
	 */
	public void startSprinting(){
        if (getCurrentStaminaPonints() > 0) {
            job.setSprinting(true);
        }
    }

	/**
	 * Sets the job of this unit to moving if the unit is spriting
	 */
	public void stopSprinting(){
		job.setSprinting(false);
    }

	/**
	 * Check if this unit is sprinting
	 * @return true if this unit's current job is sprinting else false
     */
	public boolean isSprinting(){
        return job.isSprinting();
    }


	/**
	 * Sets the current speed of this unit to any double
	 * @param speed The new speed
     */
	@Raw
    private void setCurrentSpeed(double speed){
        this.currentSpeed = speed;
    }

	/**
	 * Return the Speed of this unit.
	 * @return the Speed of this unit.
	 */
	 @Basic @Raw
	 public double getCurrentSpeed(){
        return currentSpeed;
    }

	/**
	 * Multiplies the given speed if the unit is sprinting
	 * @param speed The walking speed of the unit
	 * @return speed if walking, speed*2 if sprinting
     */
    private double getSpeed(double speed){
        if (isSprinting()){
            return speed*2;
        }else{
            return speed;
        }
    }
	/**
	 * Calculates the walking speed from and to a certain z-coordinate.
	 * @param from current z-coordinate
	 * @param to target z-coordinate
     * @return 	| if the current z is one lower
     *          |   return == 0.5*baseSpeed
	 * 			| if the current z is one higher
     * 		    |   return == 1.2*baseSpeed
	 * 			| else
     * 		    |	return == baseSpeed is returned.
     */
	private double getWalkingSpeed(double from, double to){
		double baseSpeed = getBaseSpeed();
		int dif = (int)from - (int)to;
		if(dif == -1){
			return 0.5*baseSpeed;
		}else if (dif == 1){
			return 1.2*baseSpeed;
		}else{
			return baseSpeed;
		}
	}
	/**
	 * Check whether the given move is a valid move for
	 * any unit.
	 *
     * @param  dx
     *         The x-axis to check.
     * @param  dy
     *         The y-axis to check.
     * @param  dz
     *         The z-axis to check.
     *
	 * @return
     *       | result == (-1 <= dx && dx <= 1) && (-1 <= dy && dy <= 1) && (-1 <= dz && dz <= 1)
     *
	*/
	private boolean isValidMove(int dx, int dy, int dz, Position target){
        return (-1 <= dx && dx <= 1) && (-1 <= dy && dy <= 1) && (-1 <= dz && dz <= 1) && target.isStandable();
	}

	/**
	 * Sets the orientation of this unit so that it is facing a certain change form its current coordinate.
	 * @param dx
	 * @param dy
	 * @throws ModelException
     */
	private void setOrientation(int dx, int dy) throws ModelException{
		if (dx>0 && dy==0){
			setOrientation(Orientations.RIGHT);
		}
		else if (dx<0 && dy==0){
			setOrientation(Orientations.LEFT);
		}
		else if (dx==0 && dy<0){
			setOrientation(Orientations.UP);
		}
		else if (dx==0 && dy>0){
			setOrientation(Orientations.DOWN);
		}
		else if (dx>0 && dy>0){
			setOrientation(Orientations.RIGHT_DOWN);
		}
		else if (dx<0 && dy>0){
			setOrientation(Orientations.LEFT_DOWN);
		}
		else if (dx>0 && dy<0){
			setOrientation(Orientations.RIGHT_UP);
		}
		else if (dx<0 && dy<0){
			setOrientation(Orientations.LEFT_UP);
		}

	}

	/**
	 * Starts the process of moving this unit to a block and sets this units orientation towards that block.
	 * @param dx
	 * @param dy
	 * @param dz
	 * @throws ModelException if !isValidMove(dx, dy, dz)
     */
	public void moveToAdjacent(int dx, int dy, int dz) throws ModelException{
		int[] current = this.position.getPosAsInt();
		double[] target = new double[current.length];
		target[0] = current[0] + dx + 0.5;
		target[1] = current[1] + dy + 0.5;
		target[2] = current[2] + dz + 0.5;

		setOrientation(dx, dy);

		Position targetPos = new Position(target, world);
		if (!isValidMove(dx, dy, dz, targetPos)){
			throw new ModelException("The move is invalid");
		}
		this.job = new Job(this, move);
		this.adjacentTargetPosition = targetPos;

	}

	/**
	 * Starts the process of moving this unit to a block and sets this units orientation towards that block.
	 * @param targetPosition
	 * @throws ModelException if !isValidMove(dx, dy, dz)
     */
	private void moveToAdjacent(Position targetPosition) throws ModelException {
		double[] current = this.position.getPosAsDouble();
		double[] target = targetPosition.getPosAsDouble();
		int[] d = new int[3];
		for (int i = 0; i < d.length; i++){
				d[i] = ((int)target[i] - (int)current[i]);
		}
		if (!isValidMove(d[0], d[1], d[2], targetPosition)){
			position.print();
			targetPosition.print();
			throw new ModelException("The move is invalid");
		}

		setOrientation(d[0], d[1]);

		this.job = new Job(this, move);
		this.adjacentTargetPosition = targetPosition;
	}

	/**
	 * stops the current job of the unit.
	 */
	protected void stopJob(){
		job.stopJob();
		job = new Job(this, wait);
	}

	/**
	 * Stops te moving of this unit.
	 * @throws ModelException
     */
	private void stopMovingToAdjacent() throws ModelException {
		stopJob();
		if (!isMoving() && path != null){
			try {
				moveToAdjacent(path.next());
			} catch (Path.EndOfPathException e) {
				this.adjacentTargetPosition = null;
			}
		}else{
			this.adjacentTargetPosition = null;
		}
	}

    /**
     * Returns if the unit is moving.
     * @return if the unit is moving
     */
	public boolean isMoving(){
		return job.getJob() == move;
	}

    /**
     * Moves de unit to the given cube.
     * @param cube
     * @throws ModelException
     */
	public void moveTo(int[] cube, boolean exact) throws ModelException {
		this.path = new Path(this.position, new Position(cube, world), exact);
		try {
			moveToAdjacent(path.next());
		}catch (Path.EndOfPathException e){
			stopJob();
		}
	}

	protected void advanceTimeMoving(double dt) throws ModelException {
		double[] curPos = position.getPosAsDouble();
		double[] newPos = curPos.clone();
		double[] tarPos = adjacentTargetPosition.getPosAsDouble();
		double cur, tar;
		double speed = getSpeed(getWalkingSpeed(curPos[2], tarPos[2]));
        this.setCurrentSpeed(speed);
        if (isSprinting()) {
            setCurrentStaminaPoints((int)(getCurrentStaminaPonints()- dt/0.1));
            if (getCurrentStaminaPonints() <= 0){
                stopSprinting();
            }
        }
        for (int i = 0; i<tarPos.length; i++){
			cur = curPos[i];
			tar = tarPos[i];
			if (cur < tar){
				newPos[i] = cur + speed*dt;
				if (newPos[i] > tar){
					newPos[i] = tar;
				}
			}else if(cur > tar){
				newPos[i] = cur - speed*dt;
				if (newPos[i] < tar){
					newPos[i] = tar;
				}
			}
		}

		if (Util.isSameArray(tarPos, newPos)){
			stopMovingToAdjacent();
		}

		this.position = new Position(newPos, world);
	}
    /**
     * Set the orientation of this unit to the given orientation.
     *
     * @post   If the given orientation is a valid orientation for any unit,
     *         the orientation of this new unit is equal to the given
     *         orientation.
     *       | if (isValidOrientation())
     *       |   then new.getOrientation() == this.getOrientation
     */
    @Raw
    private void setOrientationAttack(Unit target) throws ModelException {
        target.face(position);
		face(target.getPosition());
    }

	/**
	 * Set the orientation of this unit to the given orientation.
	 *
	 * @post   If the given orientation is a valid orientation for any unit,
	 *         the orientation of this new unit is equal to the given
	 *         orientation.
	 *       | if (isValidOrientation())
	 *       |   then new.getOrientation() == this.getOrientation
	 */
	@Raw
	protected void face(Position target) throws ModelException {
		double[] pos = position.getPosAsDouble();
		double[] posTarget = target.getPosAsDouble();
		setOrientation((int)posTarget[0]-(int)pos[0],(int)posTarget[1]-(int)pos[1]);
	}

    /**
     *  Sets that the unit is getting ready to attack.
     * @param value
     */
    private void setMovingToAttack(boolean value){
        this.movingToAttack = value;
    }

    /**
     * Check whether the given unit is moving to an
     * attack.
     *
     * @return
     *       | result == movingToAttack
    */
    private boolean isMovingToAttack(){
        return movingToAttack;
    }

    /**
     * Attack a unit.
     * If not adjacent to target,move to it.
     * @param target
     * @throws ModelException
     */
	public void attack(Unit target) throws ModelException {
        setTarget(target);
        if (Position.isAdjacentTo(this.position, target.position)) {
            setOrientationAttack(target);
            target.defend(this);
            setMovingToAttack(false);
            setAttacking(true);
        }else{
            moveTo(target.position.getPosAsInt(), false);
            this.path.removeLast();
            setMovingToAttack(true);
        }
	}

    /**
     * Gets the target.
     * @return The target
     */
    private Unit getTarget(){
        return target;
    }

    /**
     * sets the target.
     * @param target
     * @throws IllegalArgumentException
     */
    private void setTarget(Unit target)throws IllegalArgumentException{
        if (!isValidTarget(target)){
            throw new IllegalArgumentException("invalid target");
        }else{
            this.target = target;
        }
    }

    /**
     * Starts the work of the unit at the target position.
	 * @throws ModelException if the target is not next tho this unit
     */
	public void work(int x, int y, int z) throws ModelException {
		workTarget = new Position(new int[]{x, y, z}, world);
		try {
			movingToWork = false;
			job = new Job(this, work, workTarget);
		}catch (IllegalArgumentException e){
			//target not next to unit
			movingToWork = true;
			moveTo(workTarget.getPosAsInt(), false);
		}


    }

	/**
	 *
	 * @param position
	 * @throws ModelException
     */

	private void work(int[] position) throws ModelException {
		work(position[0], position[1], position[2]);
	}
	public void work(Position position)throws ModelException{
		work(position.getPosAsInt());
	}

    /**
     * checks if the unit is working.
     * @return if the init is working
     */
	public boolean isWorking(){
        return job.getJob() == work;
    }

    /**
     * checks if the unit is resting.
     * @return if the init is resting
     */
	public boolean isResting(){
        return job.getJob() == rest;
    }
    /**
     * Starts the rest of the unit.
     */
	public void rest(){
		job = new Job(this, rest);
    }

    /**
     * checks if the target is a valid target
     * @param target
     * @return true if the target is not terminated
     */
    private boolean isValidTarget(Unit target){
        return (!target.isTerminated());
    }
    /**
     * checks if the unit is attacking.
     * @return if the init is attacking
     */
	public boolean isAttacking(){
        return job.getJob() == attack;
    }

    /**
     * sets the unit to attack
     * @param attacking
     */
	public void setAttacking(boolean attacking){
        if (attacking){
			job = new Job (this, attack);
		}else{
			stopJob();
		}
    }

	/**
	 * There is a 0.2*(getAgility()/attacker.getAgility())) chance to call the dodge(attacker) function of this unit.
	 * Else the getRekt(attacker) function gets called.
	 * @param attacker
     */
	private void defend(Unit attacker){

        if (!Util.happensWithProbability(0.2*(getAgility()/attacker.getAgility())))
            if (Util.happensWithProbability(0.25 * (getStrength() + getAgility()) / attacker.getStrength() + attacker.getAgility())) {
                getRekt(attacker);
			}
			else{
				addExperience(20);
			}
        else{
			dodge(attacker);
        }

		if (currentHitPoints<=0){
			terminate();
		}
	}

	/**
	 * Decreases the hitpoints of this unit and stops its current job.
	 * hitpoints -= attacker.getStrength() / 10
	 * @param attacker
     */
	private void getRekt(Unit attacker){
		attacker.addExperience(20);
		setCurrentHitPoints(getCurrentHitPonits() - ((attacker.getStrength()) / 10));
		stopJob();
	}

	/**
	 * Tries to instantly move to a random neighbouring valid position.
	 * The unit calls getRekt(attacker) if there is no valid neighbouring position.
	 * @param attacker
     */
    private void dodge(Unit attacker){
		Position[] neighbours = position.getValidStandableNeighbours();
		Random rnd = new Random();
		addExperience(20);
		if (neighbours.length == 0){
			getRekt(attacker);
		}else{
			int rndI = rnd.nextInt(neighbours.length + 1);;
			this.position = new Position(neighbours[rndI].getPosAsInt(), world);
		}
    }

	/**
	 * if position.getLower().isPassable() then new.getPositionArray = current.getLower()
	 */
	private void fall() throws ModelException {
		Position lower = position.getLower();
		if(lower.isPassable()){
			this.position = lower;
			setCurrentHitPoints(this.currentHitPoints-10);
			if (currentHitPoints<=0){
				terminate();
			}
		}
	}

	/**
	 * Advances the time for this unit.
	 * @param dt
	 * @throws ModelException
     */
	public void advanceTime(double dt) throws ModelException {
		fall();
		if (isMovingToAttack()){
			attack(this.target);
		}else if (movingToWork){
			work(workTarget.getPosAsInt());
		}else{
			setCurrentSpeed(0);
		}
		job.doJob(dt);

		if (isDefaultBehaviourEnabled()){
			defaultBehaviour(dt);
		}
		if (experiencePoints >= 10) {
			setAgility(getAgility() + 1);
			setStrength(getStrength() + 1);
			setToughness(getToughness() + 1);
			experiencePoints -= 10;
		}
		if (currentHitPoints <= 0){
			terminate();
		}
	}

	/**
	 * Set the defaultBehaviour of this unit to the given defaultBehaviour.
	 *
	 * @param  defaultBehaviour
	 *         The new defaultBehaviour for this unit.
	 */
	@Raw
	public void setDefaultBehaviour(boolean defaultBehaviour){
        this.defaultBehavior = defaultBehaviour;
    }

	/**
	 * @return defaultBehavior
	 */
	 @Basic @Raw
	 public boolean isDefaultBehaviourEnabled(){
        return defaultBehavior;
    }

	private void doTask(double dt) throws ModelException{
		try {
			if (job.getJob().equals(Job.Jobs.wait)) {
				if (task.execute(dt)) {
					//task completed
					faction.scheduler.complete(task);
					task = null;
				}
			}
		}catch (ModelException e){
			task = null;
			throw e;
		}
	}

	/**
	 * Unit will randomly move to a random position,
	 * if the staminaPoints are not max, rest unit they are
	 * or work.
	 * @throws ModelException
     */
    private void defaultBehaviour(double dt) throws ModelException {
		if (task != null){
			doTask(dt);
		}else if (faction.isTaskAvailable()){
			faction.doLowestPriorityTask(this);
		} else {

			double rng = Math.random() * 3;
			int[] cube = new RndFinder().find(getPosition()).getPosAsInt();
			if (!isWorking() && !isResting() && !isMoving()) {
				if (rng < 1) {
					stopJob();
					work(cube);
				} else if (rng < 2) {
					stopJob();
					moveTo(cube, false);
				} else  if (rng < 3){
					if (getCurrentStaminaPonints() != getMaxStaminaPoints()) {
						stopJob();
						rest();
					}
				}
			}
			if (isMoving()) {
				if (getCurrentStaminaPonints() > 0 && Util.happensWithProbability(0.5)) {
					startSprinting();
				}
			}
			if (isResting()) {
				if (getCurrentStaminaPonints() == getMaxStaminaPoints()) {
					stopJob();
				}
			}
		}
	}

	/**
	 * Pickup an worldObject and remove it form the world.
	 */
	public void pickup(WorldObject worldObject){
		if (isCarrying() == null) {
			world.removeObject(worldObject);
			this.worldObject = worldObject;
			addExperience(10);
		}
	}

	/**
	 * Pickup an worldObject and remove it form the world.
	 */
	public void drop(Position position){
		worldObject.setPosition(position.getPosAsDouble());
		world.addObject(worldObject);
		worldObject = null;
		addExperience(10);
	}

	/**
	 * @return The worldObject this unit is carrying if null it is nothing
     */
	public WorldObject isCarrying(){
		return worldObject;
	}

	/**
	 * increases the xp with the given amount
	 * @param experience
     */
	public void addExperience(int experience){
		experiencePoints += experience;
	}

	/**
	 * @return return the amount of experience
	 */
	public int getExperience(){
		return experiencePoints;
	}


	

    /**
    	 * Terminate this Unit.
    	 *
    	 * @post   This Unit  is terminated.
    	 *       | new.isTerminated()
    	 */
    	 private void terminate() {
    		 this.isTerminated = true;
			 faction.removeUnit(this);
    	 }
    	 
    	 /**
    	  * Return a boolean indicating whether or not this Unit
    	  * is terminated.
    	  */
    	 @Basic
         @Raw
		 public boolean isTerminated() {
    		 return this.isTerminated;
    	 }
    	 
    	 /**
    	  * Variable registering whether this person is terminated.
    	  */

    	 private boolean isTerminated = false;


}


