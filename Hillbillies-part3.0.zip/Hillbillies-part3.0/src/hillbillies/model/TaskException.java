package hillbillies.model;

/**
 * Created by robin on 19/05/16.
 */
public class TaskException extends Exception {
    Task task;
    public TaskException(String m, Task task){
        super(m);
        this.task = task;
    }

    public void killTask(){
        task.getSchedulersForTask().forEach((scheduler -> scheduler.complete(task)));
        task.terminate();
    }
}
