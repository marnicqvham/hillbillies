package hillbillies.model;

import be.kuleuven.cs.som.annotate.Basic;
import be.kuleuven.cs.som.annotate.Raw;
import ogp.framework.util.ModelException;

import java.util.HashSet;
import java.util.Set;

/**
 * Created by Robin on 14/03/2016.
 */
public class Faction {
    private Set<Unit> members;
    private static final int maxMembers = 50;
    public Scheduler scheduler;

    public Faction() {
        members = new HashSet<>();
        scheduler = new Scheduler();
    }

    /**
     * @return result == members.size() > maxMembers
     */
    public boolean isFull(){
        return (members.size() >= maxMembers);
    }

    /**
     * Return the members of this faction.
     * @return the members of this faction.
     */
     @Basic
     @Raw
     public Set<Unit> getMembers(){
         return members;
     }

    /**
     * Adds the unit if the faction is not full.
     * @param unit The unit to add to the faction
     * @throws ModelException if this.isFull()
     */
    public void addUnit(Unit unit) throws ModelException{
        if (isFull()){
            throw new ModelException("The faction is full");
        }
        members.add(unit);
    }

    /**
     * removes the unit form this faction
     * @param unit the unit to remove form faction
     */
    public void removeUnit(Unit unit){
        members.remove(unit);
    }

    /**
     * return the amount of members of this faction
     * @return members.size();
     */
    public int size(){
        return members.size();
    }

    public void doLowestPriorityTask(Unit unit){
        scheduler.doNext(unit);
    }
    public boolean isTaskAvailable(){
        return (!scheduler.getTasks().isEmpty());
    }
}
