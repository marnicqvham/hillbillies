package hillbillies.model.statement;

import be.kuleuven.cs.som.annotate.Value;
import hillbillies.model.Task;
import hillbillies.model.TaskException;
import hillbillies.part3.programs.SourceLocation;

import java.util.List;

/**
 * Created by robin on 11/05/16.
 */
@Value
public abstract class Statement {
    public final SourceLocation sourceLocation;

    public Statement(SourceLocation sourceLocation) {
        this.sourceLocation = sourceLocation;
    }

    public abstract List<Statement> execute(Task task) throws TaskException;

    public abstract List<Statement> allStatements();
}
