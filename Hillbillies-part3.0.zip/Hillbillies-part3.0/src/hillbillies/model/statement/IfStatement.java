package hillbillies.model.statement;

import hillbillies.model.Task;
import hillbillies.model.expression.BooleanExpression.BooleanExpression;
import hillbillies.model.expression.Expression;
import hillbillies.part3.programs.SourceLocation;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Created by robin on 13/05/16.
 */
public class IfStatement extends Statement{
    public final BooleanExpression condition;
    public final Statement ifBody;
    public final Statement elseBody;

    public IfStatement(SourceLocation sourceLocation, Expression condition, Statement ifBody, Statement elseBody) {
        super(sourceLocation);
        this.condition = condition.asBooleanExpression();
        this.ifBody = ifBody;
        this.elseBody = elseBody;
    }

    @Override
    public List<Statement> execute(Task task) {
        List<Statement> solution = new ArrayList<>();
        if (condition.getValue(task)){
            if (ifBody != null) {
                solution.add(ifBody);
            }
        }else{
            if (elseBody != null) {
                solution.add(elseBody);
            }
        }
        return solution;
    }

    public List<Statement> allStatements( ) {
        List<Statement> allStatements = new ArrayList<>();
        allStatements.addAll(Arrays.asList(ifBody));
        allStatements.addAll(Arrays.asList(elseBody));

        return allStatements;
    }
}
