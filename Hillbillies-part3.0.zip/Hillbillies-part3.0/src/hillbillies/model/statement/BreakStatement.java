package hillbillies.model.statement;

import hillbillies.model.Task;
import hillbillies.part3.programs.SourceLocation;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by robin on 13/05/16.
 */
public class BreakStatement extends Statement {
    public BreakStatement(SourceLocation sourceLocation){
        super(sourceLocation);
    }

    @Override
    public List<Statement> execute(Task task) {
        return new ArrayList<>();
    }

    public List<Statement> allStatements() {
        return new ArrayList<>();
    }
}
