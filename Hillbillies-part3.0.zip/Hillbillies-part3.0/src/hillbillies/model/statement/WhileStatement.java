package hillbillies.model.statement;

import hillbillies.model.Task;
import hillbillies.model.expression.BooleanExpression.BooleanExpression;
import hillbillies.model.expression.Expression;
import hillbillies.part3.programs.SourceLocation;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;


/**
 * Created by robin on 13/05/16.
 */
public class WhileStatement extends Statement{
    public final BooleanExpression condition;
    public final Statement body;

    public WhileStatement(SourceLocation sourceLocation, Expression condition, Statement body) {
        super(sourceLocation);
        this.condition = condition.asBooleanExpression();
        this.body = body;
    }

    @Override
    public List<Statement> execute(Task task) {
        if (condition.getValue(task)){
            //while true
            return Arrays.asList(new Statement[] {body, this});
        }else{
            //while false
            return new ArrayList<>();
        }
    }

    public List<Statement> allStatements() {
        List<Statement> allStatements = new ArrayList<>();
        allStatements.addAll(Arrays.asList(body));

        return allStatements;
    }
}
