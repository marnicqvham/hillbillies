package hillbillies.model.statement;

import hillbillies.model.Task;
import hillbillies.model.TaskException;
import hillbillies.model.expression.Expression;
import hillbillies.part3.programs.SourceLocation;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Created by robin on 12/05/16.
 */
public class AssignmentStatement extends Statement {
    public final String variableName;
    public final Expression value;

    public AssignmentStatement( SourceLocation sourceLocation, String variableName , Expression value){
        super(sourceLocation);
        this.variableName = variableName;
        this.value = value;
    }

    @Override
    public List<Statement> execute(Task task) throws TaskException{
        Map<String, Expression> variables = task.getVariables();
        if (variables.containsKey(variableName)){
            Expression expression = variables.get(variableName);
            if (expression.getClass().getSuperclass() != value.getClass().getSuperclass()){
                throw new TaskException("Cannot reassign a variable to a different type", task);
            }
            variables.replace(variableName, value);

        }else{
            variables.put(variableName, value);
        }
        return new ArrayList<>();
    }

    public List<Statement> allStatements() {
        return new ArrayList<>();
    }
}
