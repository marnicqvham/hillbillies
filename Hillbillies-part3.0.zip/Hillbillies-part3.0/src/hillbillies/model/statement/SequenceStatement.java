package hillbillies.model.statement;

import hillbillies.model.Task;
import hillbillies.part3.programs.SourceLocation;

import java.util.List;

/**
 * Created by robin on 13/05/16.
 */
public class SequenceStatement extends Statement{
    public final List<Statement> statementList;

    public SequenceStatement(SourceLocation sourceLocation, List<Statement> statementList){
        super(sourceLocation);
        this.statementList = statementList;
    }

    @Override
    public List<Statement> execute(Task task) {
        return statementList;
    }

    public List<Statement> allStatements( ) {
        return statementList;
    }
}
