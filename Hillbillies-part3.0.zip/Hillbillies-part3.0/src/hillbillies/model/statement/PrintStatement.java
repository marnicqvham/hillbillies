package hillbillies.model.statement;

import hillbillies.model.Task;
import hillbillies.model.expression.Expression;
import hillbillies.part3.programs.SourceLocation;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by robin on 13/05/16.
 */
public class PrintStatement extends Statement {
    public final Expression expression;

    public PrintStatement(SourceLocation sourceLocation, Expression expression){
        super(sourceLocation);
        this.expression = expression;
    }

    @Override
    public List<Statement> execute(Task task) {
        System.out.println(expression.toString(task));
        return new ArrayList<>();
    }

    public List<Statement> allStatements( ) {
        return new ArrayList<>();
    }
}
