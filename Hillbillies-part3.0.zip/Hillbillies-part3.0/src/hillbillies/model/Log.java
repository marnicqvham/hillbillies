package hillbillies.model;

/**
 * Created by robin on 8/04/16.
 */
public class Log extends WorldObject {
    public Log(double[] position, World world, int weight) {
        super(position, world, weight);
    }

    public boolean isBoulder() {
        return false;
    }
}
