package hillbillies.model;

/**
 * Created by robin on 11/05/16.
 */
public class Activity {
}
