package hillbillies.model;

import be.kuleuven.cs.som.annotate.Basic;
import be.kuleuven.cs.som.annotate.Raw;

/**
 * Created by Robin on 14/03/2016.
 */
public abstract class WorldObject {
    private double[] position;
    private World world;
    private int weight;

    /**
     * Return the position of this unit as int.
     * @return the position of this unit as int.
     */
    @Basic
    @Raw
    public int[] getPosAsInt(){
        int[] intPos = new int[3];
        for (int i = 0; i< position.length; i++) {
            intPos[i] = (int)(position[i]);
        }
        return intPos;
    }

    public WorldObject(double[] position, World world, int weight) {
        this.position = position.clone();
        this.world = world;
        this.weight = weight;
    }
    public double[] getPositionArray() {
        return (position);
    }

    public Position getPosition() {
        return (new Position(position, world));
    }

    public void fall(){
        position[2] -= 1;
    }

    public void setPosition(double[] position) {
        this.position[0] = position[0];
        this.position[1] = position[1];
        this.position[2] = position[2];
    }
    public int getWeight(){
        return weight;
    }

    public abstract boolean isBoulder();
}





