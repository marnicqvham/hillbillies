package hillbillies.model;

import be.kuleuven.cs.som.annotate.Basic;
import be.kuleuven.cs.som.annotate.Raw;
import hillbillies.Util.Util;
import hillbillies.part2.listener.TerrainChangeListener;
import hillbillies.util.ConnectedToBorder;
import ogp.framework.util.ModelException;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

/**
 * Created by Robin on 14/03/2016.
 */
public class World {
    int[][][] terrainTypes;
    Faction[] factions;
    TerrainChangeListener modelListener;
    ConnectedToBorder connectedToBorder;
    Set<Unit> units;
    Set<Boulder> boulders;
    Set<Log> logs;

    public World(int[][][] terrainTypes, TerrainChangeListener modelListener) {
        this.terrainTypes = terrainTypes;
        this.modelListener = modelListener;
        this.connectedToBorder = new ConnectedToBorder(getNbCubesX(), getNbCubesY(), getNbCubesZ());
        this.units = new HashSet<Unit>();
        this.logs = new HashSet<Log>();
        this.boulders = new HashSet<Boulder>();
        this.factions = new Faction[5];
        for (int i = 0; i < factions.length; i++) {
            factions[i] = new Faction();
        }

    }
    /**
     * Return the factions of this World.
     * @return the factions of this World.
     */
     @Basic @Raw
     public Faction[] getFactions(){
        Arrays.sort(factions, (f1, f2) -> f1.size() - f2.size());
        return factions;
    }

    /**
     * Adds the given unit to the world.
     * @param unit  The unit to add.
     *
     */
    public void addUnit(Unit unit){
        units.add(unit);
    }
    /**
     * Return the units of this world.
     * @return the units of this world.
     */
     @Basic @Raw
     public Set<Unit> getUnits(){
        return units;
    }
    /**
     * Return the number of cubes on the x-axis of this world.
     * @return the number of cubes on the x-axis of this world.
     */
     @Basic @Raw
     public int getNbCubesX(){
        return terrainTypes.length;
    }
    /**
     * Return the number of cubes on the y-axis of this world.
     * @return the number of cubes on the y-axis of this world.
     */
    @Basic @Raw
    public int getNbCubesY(){
        return terrainTypes[0].length;
    }
    /**
     * Return the number of cubes on the z-axis of this world.
     * @return the number of cubes on the z-axis of this world.
     */
    @Basic @Raw
    public int getNbCubesZ(){
        return terrainTypes[0][0].length;
    }
    /**
     * Return the number of cubes on the x,y,z-axis of this world.
     * @return the number of cubes on the x,y,z-axis of this world.
     */
    @Basic @Raw
    int[] getNbCubesXYZ() {
        return new int[] {getNbCubesX(), getNbCubesY(), getNbCubesZ()};
    }
    /**
     * Return the boulders of this world.
     * @return the boulders of this world.
     */
     @Basic @Raw
     public Set<Boulder> getBoulders(){
        return boulders;
    }
    /**
     * Return the logs of this unit.
     * @return the logs of this unit.
     */
     @Basic @Raw
     public Set<Log> getLogs(){
        return logs;
    }


    /**
     * Return the cubeType of this cube.
     * @return the cubeType of this cube.
     */
    @Basic
    @Raw
    public int getCubeType(int x, int y, int z) throws ModelException {
        if (!isValidTerrainIndices(x, y, z)){
            throw new ModelException(String.format("%d, %d, %d are invalid indices", x, y, z));
        }

        return terrainTypes[x][y][z];
    }
    public int getCubeType(int[] pos) throws ModelException{
        return getCubeType(pos[0], pos[1],pos[2]);
    }

    /**
     * Check whether the given indices is a valid indices for
     * any cube.
     *
     * @param  x
     *         The x index to check.
     * @param  y
     *         The y index to check.
     * @param  z
     *         The y index to check.
     * @return
     *       | result == (0 <= x < getNbCubesX()) && (0 <= y < getNbCubesY()) && (0 <= z < getNbCubesZ())
    */
    private boolean isValidTerrainIndices(int x, int y, int z){
        return (0 <= x && x < getNbCubesX()) &&
               (0 <= y && y < getNbCubesY()) &&
               (0 <= z && z < getNbCubesZ());
    }

    /**
     * Set the cubeType of this cube to the given cubeType.
     *
     * @param  x
     *         The x index of the cube.
     * @param  y
     *         The y index of the cube.
     * @param  z
     *         The y index of the cube.
     * @param  value
     *         The new cubeType for this cube.
     * @post   The cubeType of this new cube is equal to
     *         the given cubeType.
     *       | new.getCubeType(x, y, z) == value
     * @throws ModelException
     *         The given cubeType is not a valid cubeType for any
     *         object_name_Eng.
     *       | ! isValidCubeType(getCubeType())
     */
    @Raw
    public void setCubeType(int x, int y, int z, int value) throws ModelException {
        if (!isValidCubeType(value)){
            throw new ModelException(String.format("%d is an invalid cubeType", value));
        }
        if (!isValidTerrainIndices(x, y, z)){
            throw new ModelException(String.format("%d, %d, %d are invalid indices", x, y, z));
        }
        terrainTypes[x][y][z] = value;
        modelListener.notifyTerrainChanged(x, y, z);
    }

    /**
     * Check whether the given cubeType is a valid cubeType for
     * any cube.
     *
     * @param  cubeType
     *         The cubeType to check.
     * @return
     *       | result == 0 <= cubeType <= 3
    */
    private boolean isValidCubeType(int cubeType){
        return (0 <= cubeType) && (cubeType <= 3);
    }

    /**
     * Return whether the cube is connected to the border of this world.
     * @return whether the cube is connected to the border of this world.
     * @throws ModelException
     */
    @Basic @Raw
    public boolean isSolidConnectedToBorder(int x, int y, int z) throws ModelException {
        if (!isValidTerrainIndices(x, y, z)) {
            throw new ModelException(String.format("%d, %d, %d are invalid indices", x, y, z));
        }
        return connectedToBorder.isSolidConnectedToBorder(x, y, z);
    }

    /**
     * Destroys the cubes that are not connected where isSolidConnectedToBorder() == false;
     */
    public void advanceTime() throws ModelException {
        for (int x = 0; x < getNbCubesX(); x++) {
            for (int y = 0; y < getNbCubesY(); y++) {
                for (int z = 0; z < getNbCubesZ(); z++) {
                    if (getCubeType(x, y, z)==0){
                        connectedToBorder.changeSolidToPassable(x, y, z);
                    }
                    if(!isSolidConnectedToBorder(x, y, z)){
                        destroyCube(x, y, z);
                    }
                }
            }
        }
        boulders.stream().filter(boulder -> !new Position(boulder.getPosAsInt(), this).isStandable()).forEach(boulder -> {
            boulder.fall();
        });
    }

    /**
     * Destroy a cube
     * @throws ModelException
     */
    private void destroyCube(int x, int y, int z) throws ModelException {
        int type = getCubeType(x, y, z);
        setCubeType(x, y, z, 0);
        if (Util.happensWithProbability(.5)) {
            if (type == 2) {
                logs.add(new Log(new double[]{x + .5, y + .5, z + .5}, this, 0)); // what is weight??
            } else if (type == 1) {
                boulders.add(new Boulder(new double[]{x + .5, y + .5, z + .5}, this, 0));
            }
        }
    }
    /**
     * Destroy a cube
     * @throws ModelException
     */
    public void destroyCube(int[] position) throws ModelException{
        destroyCube(position[0], position[1], position[2]);
    }

    /**
     * removes the given object form it's list
     * @param object
     */
    public void removeObject(WorldObject object){
        if(object.isBoulder()){
            boulders.remove(object);
        }else {
            logs.remove(object);
        }
    }

    /**
     * Add the given object to the correct list
     */
    public void addObject(WorldObject object){
        if(object.isBoulder()){
            boulders.add(new Boulder(object.getPositionArray(), this, object.getWeight()));
        }else {
            logs.add(new Log(object.getPositionArray(), this, object.getWeight()));
        }
    }
}
