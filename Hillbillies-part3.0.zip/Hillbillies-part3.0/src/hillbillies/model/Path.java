package hillbillies.model;

import be.kuleuven.cs.som.annotate.Basic;
import be.kuleuven.cs.som.annotate.Raw;
import hillbillies.Util.Util;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/**
 * Created by Robin on 22/02/2016.
 * GELUKKIGE VERJAARDAG ROBIN
 */
public class Path implements Comparable<Path>{
    ArrayList<Position> path;

    public int compareTo(Path other){
        return Integer.compare(this.path.size(), other.path.size());
    }

    /**
     * @param currentPosition staring position
     * @param targetPosition goal
     * @param exact set to true if the path needs to reach the target, if the target is unreachable the path will be empty
     *              set to false if a path to a valid adjacent neighbour is also good.
     */
    public Path(Position currentPosition, Position targetPosition, boolean exact) {
        path = new ArrayList<>();
        path.add(currentPosition);
        try {
            if (!targetPosition.isStandable()){
                if(exact){
                    throw new UnreachableTargetException();
                }else{
                    List<Position> neighbours = Arrays.asList(targetPosition.getValidStandableNeighbours());
                    ArrayList<Path> paths = new ArrayList<>();
                    Path path;
                    for (Position neighbour:neighbours) {
                        path = new Path(currentPosition, neighbour, true);
                        if (!path.isTerminated()) {
                            this.path = path.path;
                            return; //// TODO: 10/04/16 works but not optimal
                        }
                    }
                }
            }else{
                path = findPath(targetPosition, path);
            }
        }catch (UnreachableTargetException e){
            terminate();
        }
        path.remove(0); //remove current pos from path
    }

    /**
     * gets the next position in the path.
     * @return the position
     */
    public Position next() throws EndOfPathException {
        if (isTerminated()){
            throw new EndOfPathException();
        }
        if (path.size()==0){
            terminate();
            throw new EndOfPathException();
        }
        Position pos = path.get(0);
        if (!isTerminated()){
            path.remove(0);
        }
        return pos;
    }

    /**
     * Finds the path of the unit to a target.
     * @param goal
     * @param path
     * @return the path
     * @throws UnreachableTargetException if the target is unreachable
     */
    private ArrayList<Position> findPath(Position goal,
                                         ArrayList<Position> path) throws UnreachableTargetException {
        Position origin = path.get(0);
        ArrayList<PartialPath> openList = new ArrayList<>();
        openList.add(new PartialPath(origin, goal));
        ArrayList<Position> closedList = new ArrayList<>();
        PartialPath current;

        while (true){
            Collections.sort(openList);
            current = openList.get(0);
            Position[] validNeighbours = current.getLastPosition().getValidStandableNeighbours();
            for (Position validNeighbour : validNeighbours) {
                if (Util.isSameArray(validNeighbour.getPosAsInt(), goal.getPosAsInt())){
                    path = current.getPath();
                    path.add(validNeighbour);
                    return path;
                }else if(!lastPosOnPathList(validNeighbour, openList) && !lastPosOnPosList(validNeighbour, closedList)){
                    openList.add(new PartialPath(current, validNeighbour));
                }
            }
            openList.remove(current);
            closedList.add(current.getLastPosition());
            cleanOpenList(openList, closedList);

            if(openList.size() == 0){
                throw new UnreachableTargetException();
            }
        }
    }
    /**
     * Return the last position of this path.
     * @return the last position of this path.
     */
     @Basic @Raw
    private boolean lastPosOnPathList(Position pos, ArrayList<PartialPath> list){
        for (PartialPath path:list) {
            if(Util.isSameArray(path.getLastPosition().getPosAsInt(), pos.getPosAsInt())){
                return true;
            }
        }
        return false;
    }
    /**
     * Return the last position of this path.
     * @return the last position of this path.
     */
    @Basic @Raw
    private boolean lastPosOnPosList(Position pos, ArrayList<Position> list){
        for (Position position:list){
            if(Util.isSameArray(pos.getPosAsInt(), position.getPosAsInt())){
                return true;
            }
        }
        return false;
    }

    // TODO: 9/04/2016 commentaar
    private void cleanOpenList(ArrayList<PartialPath> openList, ArrayList<Position> closedList){
        for (PartialPath path: new ArrayList<>(openList)) {
            if (closedList.contains(path)){
                openList.remove(path);
            }
        }
    }

    // TODO: 9/04/2016 commentaar
    private boolean isOnList(ArrayList<Position> list, Position position){
        for (Position closedPos: list) {
            if(Util.isSameArray(closedPos.getPosAsInt(), position.getPosAsInt())){
                return true;
            }
        }
        return false;
    }

    /**
     * print the path of the unit
     */
    public void print(){
       System.out.println("---Printing-Path---");
       path.forEach(Position::print);

}

    /**
     * removes the last step of the path
     */
    public void removeLast(){
        this.path.remove(path.size()-1);
    }

    /**
     * Terminate this path.
     *
     * @post   This path  is terminated.
     *       | new.isTerminated()
     * @post   path = null
     */
     public void terminate() {
         this.isTerminated = true;
         path = null;
     }

     /**
      * Return a boolean indicating whether or not this path
      * is terminated.
      */
     @Basic
     @Raw
     public boolean isTerminated() {
         return this.isTerminated;
     }

     /**
      * Variable registering whether this person is terminated.
      */
     private boolean isTerminated = false;

    /**
     *
     */
    class PartialPath implements Comparable<PartialPath> {
        private ArrayList<Position> path;
        private final Position goal;
        private int g;

        public PartialPath(ArrayList<Position> path, Position goal, int g) {
            this.path = path;
            this.goal = goal;
            this.g = g;
        }

        public PartialPath(Position position, Position goal){
            this.goal = goal;
            this.g = 0;
            this.path = new ArrayList<>();
            this.path.add(position);
        }

        public PartialPath(PartialPath previousPath, Position newPosition){
            this.goal = previousPath.goal;
            this.path = new ArrayList<>(previousPath.getPath());
            this.path.add(newPosition);
            this.g = previousPath.getGValue() + 10;
            if(isDiagonal(previousPath.getLastPosition(), newPosition)){
                this.g += 4; //+4 if diagonal because diagonal takes longer.
            }
        }

        private boolean isDiagonal(Position position1, Position position2){
            int[] p1 = position1.getPosAsInt();
            int[] p2 = position2.getPosAsInt();
            int j = 0;
            for (int i = 0; i < p1.length; i++) {
                if((p1[i]-p2[i])!=0){
                    j++;
                }
            }
            if(j>1){
                return true;
            }else{
                return false;
            }
        }

        public int getHValue(){
            return path.get(path.size()-1).getAmountOfPositionsTo(goal)*10;
        }

        public int getGValue(){
            return g;
        }

        public int getFValue(){
            return getHValue() + g;
        }

        public Position getLastPosition(){
            return path.get(path.size()-1);
        }

        private ArrayList<Position> getPath(){
            return path;
        }

        public int compareTo(PartialPath other){
            return Integer.compare(getFValue(), other.getFValue());
        }

    }

    class UnreachableTargetException extends Exception{    }
    class EndOfPathException extends Exception{}

}
