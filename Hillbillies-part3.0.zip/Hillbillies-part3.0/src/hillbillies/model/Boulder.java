package hillbillies.model;


public class Boulder extends WorldObject {
    /**
     * Extends the class worldObject where all the objects in a world are combined.
     * @param position The position of the boulder.
     * @param world The world of the boulder.
     * @param weight The weight of the boulder.
     */
    public Boulder(double[] position, World world, int weight){
        super(position, world, weight);
    }

    public boolean isBoulder(){
        return true;
    }
}