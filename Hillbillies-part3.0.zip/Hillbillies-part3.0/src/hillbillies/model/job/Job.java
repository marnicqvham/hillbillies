package hillbillies.model.job;

import be.kuleuven.cs.som.annotate.Basic;
import be.kuleuven.cs.som.annotate.Raw;
import hillbillies.model.Unit;

/**
 * Created by Robin on 9/03/2016.
 */
public abstract class Job {
    private Unit unit;
    private double jobTime;
    private boolean isTerminated = false;

    public Job(Unit unit){
        this.unit = unit;
        jobTime = 0;
    }

    public void advanceTime(double dt){
        //do nothing
    }

    /**
    	 * Terminate this Job.
    	 *
    	 * @post   This Job  is terminated.
    	 *       | new.isTerminated()
    	 * @post   ...
    	 *       | ...
    	 */
    	 public void terminate() {
    		 this.isTerminated = true;
    	 }

    	 /**
    	  * Return a boolean indicating whether or not this Job
    	  * is terminated.
    	  */
    	 @Basic @Raw
    	 public boolean isTerminated() {
    		 return this.isTerminated;
    	 }
}
