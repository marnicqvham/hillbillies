package hillbillies.model;

import java.util.*;
import java.util.function.Predicate;
import java.util.stream.Collectors;

/**
 * Created by robin on 2/05/16.
 */
public class Scheduler {
    private ArrayList<Task> tasks;

    public Scheduler() {
        this.tasks = new ArrayList<>();
    }

    public void complete(Task task){
        tasks.remove(task);
        task.terminate();
    }

    /**
     * Add a task to the scheduler
     * @param task
     **/
    public void add(Task task){
        tasks.add(task);
        task.addedToScheduler(this);
    }

    /**
     * Add all tasks
     * @param tasks collection of tasks to add
     */
    private void addAll(Collection<Task> tasks){
        tasks.addAll(tasks);
    }

    /**
     * remove a task from the scheduler
     * @param task
     */
    private void remove(Task task){
        tasks.remove(task);
        task.removedFromScheduler(this);
    }

    /**
     * remove all tasks
     * @param tasks collection of tasks to remove
     */
    private void removeAll(Collection<Task> tasks){
        tasks.removeAll(tasks);
    }

    /**
     * replace the given task with the other task
     * @param
     */
    public void replaceTask(Task old, Task newTask){
        if (old.isExecuting())
            old.failTask();
        if (tasks.contains(old)) {
            tasks.remove(tasks.indexOf(old));
            tasks.add(newTask);
        }
    }
    /**
     * Assign the next task to this unit.
     * @unit
     */
    public void doNext(Unit unit){
        next().assignUnit(unit);
    }

    /**
     * @return the task with the highest priority that is not being executed if there is no such task null will be returned
     */
    private Task next(){
        return unassignedTasks().get(0);
    }
    private static Predicate<Task> isUnassingned(){
        return s -> !s.isExecuting();
    }

    /**
     * @return A sorted list of unassigned tasks.
     */
    private List<Task> unassignedTasks(){
        List<Task> unassignedTasks = getTasksWithCondition(isUnassingned());
        Collections.sort(unassignedTasks, new Comparator<Task>() {
            @Override
            public int compare(Task o1, Task o2) {
                return Integer.compare(o2.getPriority(),o1.getPriority());
            }
        });
        return unassignedTasks;
    }

    /**
     * @return A sorted list of all tasks.
     */
    public List<Task> getTasks(){
        Collections.sort(tasks, new Comparator<Task>() {
            @Override
            public int compare(Task o1, Task o2) {
                return Integer.compare(o2.getPriority(),o1.getPriority());
            }
        });;
        return tasks;
    }
    private List<Task> getTasksWithCondition(Predicate<Task> condition){
        return tasks.stream().filter(condition).collect(Collectors.toList());
    }

    /**
     * @param task The task to check for.
     * @return True if the scheduler contains the task, else false
     */
    private boolean contains(Task task){
        return tasks.contains(task);
    }

    /**
     * @param tasks collection of tasks to look for
     * @return true if all the tasks in the collection are in this scheduler.
     */
    public boolean containsAll(Collection<Task> tasks){
        return tasks.containsAll(tasks);
    }
}
