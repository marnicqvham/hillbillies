package hillbillies.model;

import hillbillies.model.expression.*;
import hillbillies.model.expression.BooleanExpression.*;
import hillbillies.model.expression.position.Unit.*;
import hillbillies.model.expression.position.*;
import hillbillies.model.statement.*;
import hillbillies.model.statement.action.AttackActionStatement;
import hillbillies.model.statement.action.FollowActionStatement;
import hillbillies.model.statement.action.MoveToActionStatement;
import hillbillies.model.statement.action.WorkActionStatement;
import hillbillies.part3.programs.ITaskFactory;
import hillbillies.part3.programs.SourceLocation;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by robin on 11/05/16.
 */
public class TaskFactory implements ITaskFactory<Expression, Statement, Task> {
    @Override
    public List<Task> createTasks(String name, int priority, Statement activity, List<int[]> selectedCubes) {
        List<Task> tasks = new ArrayList<>();
        if (selectedCubes.isEmpty()){
            tasks.add(new Task(name, priority, activity, null));
        }else {
            selectedCubes.forEach((cube) -> tasks.add(new Task(name, priority, activity, cube))); //lambda !!
        }
        return tasks;
    }

    @Override
    public Statement createAssignment(String variableName, Expression value, SourceLocation sourceLocation) {
        return new AssignmentStatement(sourceLocation, variableName, value);
    }

    @Override
    public Statement createWhile(Expression condition, Statement body, SourceLocation sourceLocation) {
        return new WhileStatement(sourceLocation, condition, body);
    }

    @Override
    public Statement createIf(Expression condition, Statement ifBody, Statement elseBody, SourceLocation sourceLocation) {
        return new IfStatement(sourceLocation, condition, ifBody, elseBody);
    }

    @Override
    public Statement createBreak(SourceLocation sourceLocation) {
        return new BreakStatement(sourceLocation);
    }

    @Override
    public Statement createPrint(Expression value, SourceLocation sourceLocation) {
        return new PrintStatement(sourceLocation, value);
    }

    @Override
    public Statement createSequence(List<Statement> statements, SourceLocation sourceLocation) {
        return new SequenceStatement(sourceLocation, statements);
    }

    @Override
    public Statement createMoveTo(Expression position, SourceLocation sourceLocation) {
        return new MoveToActionStatement(sourceLocation, position);
    }

    @Override
    public Statement createWork(Expression position, SourceLocation sourceLocation) {
        return new WorkActionStatement(sourceLocation, position);
    }

    @Override
    public Statement createFollow(Expression unit, SourceLocation sourceLocation) {
        return new FollowActionStatement(sourceLocation, (UnitExpression)unit);
    }

    @Override
    public Statement createAttack(Expression unit, SourceLocation sourceLocation) {
        return new AttackActionStatement(sourceLocation, (UnitExpression)unit);
    }

    @Override
    public Expression createReadVariable(String variableName, SourceLocation sourceLocation) {
        return new VariableExpression(sourceLocation, variableName);
    }

    @Override
    public Expression createIsSolid(Expression position, SourceLocation sourceLocation) {
        return new IsSolidExpression(position, sourceLocation);
    }

    @Override
    public Expression createIsPassable(Expression position, SourceLocation sourceLocation) {
        return new IsPassableExpression(position, sourceLocation);
    }

    @Override
    public Expression createIsFriend(Expression unit, SourceLocation sourceLocation) {
        return new IsFriendexpression(unit, sourceLocation);
    }

    @Override
    public Expression createIsEnemy(Expression unit, SourceLocation sourceLocation) {
        return new IsEnemyExpression(unit, sourceLocation);
    }

    @Override
    public Expression createIsAlive(Expression unit, SourceLocation sourceLocation) {
        return new IsAliveExpression(unit, sourceLocation);
    }

    @Override
    public Expression createCarriesItem(Expression unit, SourceLocation sourceLocation) {
        return new CarriesItemExpression(unit, sourceLocation);
    }

    @Override
    public Expression createNot(Expression expression, SourceLocation sourceLocation) {
        return new NotExpression(expression, sourceLocation);
    }

    @Override
    public Expression createAnd(Expression left, Expression right, SourceLocation sourceLocation) {
        return new AndExpression(left, right, sourceLocation);
    }

    @Override
    public Expression createOr(Expression left, Expression right, SourceLocation sourceLocation) {
        return new OrExpression(left, right, sourceLocation);
    }

    @Override
    public Expression createHerePosition(SourceLocation sourceLocation) {
        return new HerePositionExpression(sourceLocation);
    }

    @Override
    public Expression createLogPosition(SourceLocation sourceLocation) {
        return new LogPositionExpression(sourceLocation);
    }

    @Override
    public Expression createBoulderPosition(SourceLocation sourceLocation) {
        return new BoulderPositionExpression(sourceLocation);
    }

    @Override
    public Expression createWorkshopPosition(SourceLocation sourceLocation) {
        return new WorkshopPositionExpression(sourceLocation);
    }

    @Override
    public Expression createSelectedPosition(SourceLocation sourceLocation) {
        return new SelectedPositionExpression(sourceLocation);
    }

    @Override
    public Expression createNextToPosition(Expression position, SourceLocation sourceLocation) {
        return new NextToPositionExpression(position, sourceLocation);
    }

    @Override
    public Expression createLiteralPosition(int x, int y, int z, SourceLocation sourceLocation) {
        return new LiteralPositionExpression(x, y, z, sourceLocation);
    }

    @Override
    public Expression createThis(SourceLocation sourceLocation) {
        return new ThisUnitExpression(sourceLocation);
    }

    @Override
    public Expression createFriend(SourceLocation sourceLocation) {
        return new FriendUnitExpression(sourceLocation);
    }

    @Override
    public Expression createEnemy(SourceLocation sourceLocation) {
        return new EnemyUnitExpression(sourceLocation);
    }

    @Override
    public Expression createAny(SourceLocation sourceLocation) {
        return new AnyUnitExpression(sourceLocation);
    }

    @Override
    public Expression createTrue(SourceLocation sourceLocation) {
        return new TrueExpression(sourceLocation);
    }

    @Override
    public Expression createFalse(SourceLocation sourceLocation) {
        return new FalseExpression(sourceLocation);
    }
}
