package hillbillies.model;

import be.kuleuven.cs.som.annotate.Basic;
import be.kuleuven.cs.som.annotate.Raw;
import hillbillies.Util.Util;
import ogp.framework.util.ModelException;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Created by robin on 8/04/16.
 */
public class Job {
    enum Jobs{
        wait, work, move, attack, rest
    }
    private Unit unit;
    private Boolean sprinting;
    private double jobTime;
    private Jobs job;
    private Position targetPosition;


    public Job(Unit unit, Jobs job){
        this.unit = unit;
        this.job = job;
        this.sprinting = false;
        this.jobTime = 0;
    }

    public Job(Unit unit, Jobs job, Position targetPosition) throws ModelException {
        this(unit, job);
        this.targetPosition = targetPosition;
        if (!targetPosition.isAdjacentTo(unit.getPosition())){
            throw new IllegalArgumentException("The target position is not next to the unit");
        }
        unit.face(targetPosition);
    }

    /**
     * Set the sprinting of this unit to the given boolean.
     * @param  sprinting
     *         The new value for this unit.
     */
    public void setSprinting(Boolean sprinting){
        this.sprinting = sprinting; //// FIXME: 8/04/16 sprinting
    }
    /**
     * Check whether the given unit is sprinting.
     *
     * @return
     *       | result == sprinting
    */
    public boolean isSprinting(){
        return sprinting;
    }

    /**
     * returns the current job of the unit.
     * @return job
     */
    public Jobs getJob(){
        return job;
    }

    /**
     * Advances the time donig a job
     * @param dt
     * @throws ModelException
     *          |if NullPointerException
     *          | StopJob
     */
    public void doJob(double dt) throws ModelException {
        try {
            switch (getJob()) {
                case move:
                    unit.advanceTimeMoving(dt);
                    break;
                case attack:
                    attack(dt);
                    break;
                case work:
                    work(dt);
                    break;
                case rest:
                    rest(dt);
            }
        }catch (NullPointerException e){
            unit.stopJob();
        }
    }

    /**
     * Lets the unit attack.
     * @param dt
     */
    private void attack(double dt){
        jobTime += dt;
        if (jobTime >= 1){
            unit.setAttacking(false);
            stopJob();
        }
    }

    /**
     * Lets the unit work.
     * @param dt
     */
    private void work(double dt) throws ModelException{
        jobTime += dt;
        double taskTime = 500/unit.getStrength();
        if (jobTime >= taskTime){
            jobFinished();
            stopJob();
            unit.addExperience(10);
        }
    }

    /**
     * Does the task when job is finished.
     */
    private void jobFinished() throws ModelException{
        //if carrying boulder/log drop it
        WorldObject object = unit.isCarrying();
        if (object != null && targetPosition.isStandable()){
            unit.drop(targetPosition);
            return;
        }
        Set<WorldObject> objects = new HashSet<>();
        objects = targetPosition.getObjectHere();

        //if target is workshop and there is a boulder and a log
        if (unit.world.getCubeType(targetPosition.getPosAsInt()[0],targetPosition.getPosAsInt()[1],targetPosition.getPosAsInt()[2]) == 3){
            List<WorldObject> boulderAndLog = Util.getBoulderAndLogInSet(objects);
            if (boulderAndLog.size() == 2){
                unit.world.removeObject(boulderAndLog.get(0));
                unit.world.removeObject(boulderAndLog.get(1));
                unit.setWeight(unit.getWeight()+1);
                unit.setToughness(unit.getToughness()+1);

            }
        }


        //pickup log/boulder

        if (objects.size() != 0){
            unit.pickup(objects.iterator().next());
            unit.addExperience(10);
            return;

        }


        //destroy target cube
        try {
            unit.world.destroyCube(targetPosition.getPosAsInt());
        } catch (ModelException e) {}

    }


    /**
     * Lets the unit rest.
     * @param dt
     */
    private void rest(double dt) {
        boolean stop = false;
        jobTime += dt;
        if (unit.getCurrentHitPonits() < unit.getMaxHitPoints()) {
            double recoverspeed = (double) (unit.getToughness()) / 100;
            jobTime += recoverspeed / (dt / 0.2);
            if (jobTime > 1) {
                unit.setCurrentHitPoints(unit.getCurrentHitPonits() + 1);
                jobTime -= 1;
                stop = true;
            }
        } else {
            if (unit.getCurrentStaminaPonints() < unit.getMaxStaminaPoints()) {
                double recoverspeed = (double) (unit.getToughness()) / 200;
                jobTime += recoverspeed / (dt / 0.2);
                if (jobTime > 1) {
                    unit.setCurrentStaminaPoints(unit.getCurrentStaminaPonints() + 1);
                    jobTime -= 1;
                    stop = true;
                }
            }else if (stop){
                stopJob();
            }

        }
    }

    /**
     * Stop this job.
     *
     * @post   This path  is terminated.
     *       | new.isTerminated()
     *       | new.getJob() == wait
     */
    public void stopJob() {
        this.isTerminated = true;
        this.job = Jobs.wait;
    }

    /**
     * Return a boolean indicating whether or not this path
     * is terminated.
     */
    @Basic
    @Raw
    public boolean isTerminated() {
        return this.isTerminated;
    }

    /**
     * Variable registering whether this person is terminated.
     */
    private boolean isTerminated = false;

}
