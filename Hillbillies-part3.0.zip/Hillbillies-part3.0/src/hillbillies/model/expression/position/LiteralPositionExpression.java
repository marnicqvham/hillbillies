package hillbillies.model.expression.position;

import hillbillies.model.Position;
import hillbillies.model.Task;
import hillbillies.part3.programs.SourceLocation;

/**
 * Created by marnicq van ham on 12/05/2016.
 */
public class LiteralPositionExpression extends PositionExpression {
    public int x,y,z;
    public LiteralPositionExpression(int x, int y, int z, SourceLocation sourceLocation){
        super(sourceLocation);
        this.x = x;
        this.y = y;
        this.z = z;
    }

    @Override
    public Position getValue(Task task) {
        return new Position(new int[] {x, y, z}, task.getWorld()); //// TODO: 17/05/16 give world
    }

    @Override
    public String toString(Task task) {
        return "Literal position: " + getValue(task).toString();
    }
}
