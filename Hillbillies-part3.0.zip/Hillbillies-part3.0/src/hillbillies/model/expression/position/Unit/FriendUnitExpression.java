package hillbillies.model.expression.position.Unit;

import hillbillies.Util.UnitFinder;
import hillbillies.model.Task;
import hillbillies.model.Unit;
import hillbillies.part3.programs.SourceLocation;

/**
 * Created by marnicq van ham on 12/05/2016.
 */
public class FriendUnitExpression extends UnitExpression {
    public FriendUnitExpression(SourceLocation sourceLocation){
        super(sourceLocation);
    }

    @Override
    public Unit getUnit(Task task) {
        return new UnitFinder().find(task.getUnit().getPosition(), task.getUnit().faction.getMembers());
    }
}
