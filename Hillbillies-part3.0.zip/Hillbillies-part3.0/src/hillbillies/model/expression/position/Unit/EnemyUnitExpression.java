package hillbillies.model.expression.position.Unit;

import hillbillies.Util.UnitFinder;
import hillbillies.model.Faction;
import hillbillies.model.Task;
import hillbillies.model.Unit;
import hillbillies.part3.programs.SourceLocation;

import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * Created by marnicq van ham on 12/05/2016.
 */
public class EnemyUnitExpression extends UnitExpression {
    public EnemyUnitExpression(SourceLocation sourceLocation){
        super(sourceLocation);
    }

    @Override
    public Unit getUnit(Task task) {
        Set<Unit> enemies = new HashSet<>();
        Faction[] factions = task.getWorld().getFactions();
        List<Faction> enemieFactions = Arrays.stream(factions).filter(f -> !f.equals(task.getUnit().getFaction())).collect(Collectors.toList());
        for (Faction enemieFaction :
                enemieFactions) {
            enemies.addAll(enemieFaction.getMembers());
        }

        return new UnitFinder().find(task.getUnit().getPosition(), enemies);
    }
}
