package hillbillies.model.expression.position.Unit;

import hillbillies.model.Position;
import hillbillies.model.Task;
import hillbillies.model.Unit;
import hillbillies.model.expression.position.PositionExpression;
import hillbillies.part3.programs.SourceLocation;

/**
 * Created by robin on 16/05/16.
 */
public abstract class UnitExpression extends PositionExpression {
    public UnitExpression(SourceLocation sourceLocation){
        super(sourceLocation);
    }

    public abstract Unit getUnit(Task task);

    public Position getValue(Task task){
        return this.getUnit(task).getPosition();
    }

    @Override
    public String toString(Task task) {
        return "Unit: " + getUnit(task).getName() + getUnit(task).getPosition().toString();
    }

    @Override
    public UnitExpression asUnitExpression() throws ClassCastException {
        return this;
    }
}
