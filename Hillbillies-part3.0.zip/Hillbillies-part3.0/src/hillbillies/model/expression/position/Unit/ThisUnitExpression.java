package hillbillies.model.expression.position.Unit;

import hillbillies.model.Task;
import hillbillies.model.Unit;
import hillbillies.part3.programs.SourceLocation;

/**
 * Created by marnicq van ham on 12/05/2016.
 */
public class ThisUnitExpression extends UnitExpression {
    public ThisUnitExpression(SourceLocation sourceLocation){
        super(sourceLocation);
    }

    @Override
    public Unit getUnit(Task task) {
        return task.getUnit();
    }
}
