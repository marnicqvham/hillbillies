package hillbillies.model.expression.position.Unit;

import hillbillies.model.Position;
import hillbillies.model.Task;
import hillbillies.model.Unit;
import hillbillies.part3.programs.SourceLocation;

/**
 * Created by robin on 20/05/16.
 */
public class VariableUnitExpression extends UnitExpression{
    public final String key;
    public VariableUnitExpression(SourceLocation sourceLocation, String key) {
        super(sourceLocation);
        this.key = key;
    }

    @Override
    public Unit getUnit(Task task) {
        return ((UnitExpression)task.getVariable(key)).getUnit(task);
    }

    @Override
    public Position getValue(Task task) {
        return ((UnitExpression)task.getVariable(key)).getValue(task);
    }

    @Override
    public String toString(Task task) {
        return getValue(task).toString();
    }
}
