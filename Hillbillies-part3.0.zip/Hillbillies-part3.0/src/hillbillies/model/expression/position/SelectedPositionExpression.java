package hillbillies.model.expression.position;

import hillbillies.model.Position;
import hillbillies.model.Task;
import hillbillies.part3.programs.SourceLocation;

/**
 * Created by marnicq van ham on 12/05/2016.
 */
public class SelectedPositionExpression extends PositionExpression {
    public SelectedPositionExpression(SourceLocation sourceLocation){
        super(sourceLocation);
    }

    @Override
    public Position getValue(Task task) {
        return new Position(task.selectedCube, task.getWorld());
    }

    @Override
    public String toString(Task task) {
        return "positie:" + new Position(task.selectedCube, task.getWorld());
    }
}
