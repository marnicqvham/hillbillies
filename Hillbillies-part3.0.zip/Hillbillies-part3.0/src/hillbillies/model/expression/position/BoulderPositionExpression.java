package hillbillies.model.expression.position;

import hillbillies.Util.WorldObjectFinder;
import hillbillies.model.Boulder;
import hillbillies.model.Position;
import hillbillies.model.Task;
import hillbillies.part3.programs.SourceLocation;

/**
 * Created by marnicq van ham on 12/05/2016.
 */
public class BoulderPositionExpression extends PositionExpression {
    public BoulderPositionExpression(SourceLocation sourceLocation){
        super(sourceLocation);
    }

    @Override
    public Position getValue(Task task) {
        return new WorldObjectFinder<Boulder>().find(task.getUnit().getPosition(), task.getWorld().getBoulders());
    }

    @Override
    public String toString(Task task) {
        return "Boulder at " + getValue(task).toString();
    }
}
