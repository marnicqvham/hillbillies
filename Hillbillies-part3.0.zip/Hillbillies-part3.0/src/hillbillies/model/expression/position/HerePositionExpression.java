package hillbillies.model.expression.position;

import hillbillies.model.Position;
import hillbillies.model.Task;
import hillbillies.part3.programs.SourceLocation;

/**
 * Created by marnicq van ham on 12/05/2016.
 */
public class HerePositionExpression extends PositionExpression {
    public HerePositionExpression(SourceLocation sourceLocation){
        super(sourceLocation);
    }

    @Override
    public Position getValue(Task task) {
        return task.getUnit().getPosition().getLower();
    }

    @Override
    public String toString(Task task) {
        return "Here: " + getValue(task).toString();
    }
}
