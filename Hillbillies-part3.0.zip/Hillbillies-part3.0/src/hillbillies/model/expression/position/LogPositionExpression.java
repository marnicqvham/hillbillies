package hillbillies.model.expression.position;

import hillbillies.Util.WorldObjectFinder;
import hillbillies.model.Log;
import hillbillies.model.Position;
import hillbillies.model.Task;
import hillbillies.part3.programs.SourceLocation;

/**
 * Created by marnicq van ham on 12/05/2016.
 */
public class LogPositionExpression extends PositionExpression{
    public LogPositionExpression(SourceLocation sourceLocation){
        super(sourceLocation);
    }

    @Override
    public Position getValue(Task task) {
        return new WorldObjectFinder<Log>().find(task.getUnit().getPosition(), task.getWorld().getLogs());

    }

    @Override
    public String toString(Task task) {
        return "Log at " + getValue(task).toString();
    }
}
