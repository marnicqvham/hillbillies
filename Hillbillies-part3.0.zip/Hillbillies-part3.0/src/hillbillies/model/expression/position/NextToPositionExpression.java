package hillbillies.model.expression.position;

import hillbillies.model.Position;
import hillbillies.model.Task;
import hillbillies.model.expression.Expression;
import hillbillies.part3.programs.SourceLocation;

/**
 * Created by marnicq van ham on 12/05/2016.
 */
public class NextToPositionExpression extends PositionExpression{
    public Expression<Position> position;
    public NextToPositionExpression(Expression<Position> position, SourceLocation sourceLocation){
        super(sourceLocation);
        this.position = position;
    }

    @Override
    public Position getValue(Task task) {
        return position.getValue(task).getValidStandableNeighbours()[0];
    }

    @Override
    public String toString(Task task) {
        return "position next to" + position.getValue(task).toString() + "is" + position.getValue(task).getValidStandableNeighbours()[0];
    }
}
