package hillbillies.model.expression.position;

import hillbillies.model.Position;
import hillbillies.model.expression.Expression;
import hillbillies.part3.programs.SourceLocation;

/**
 * Created by robin on 19/05/16.
 */
public abstract class PositionExpression extends Expression<Position> {
    public PositionExpression(SourceLocation sourceLocation){
        super(sourceLocation);
    }

    @Override
    public PositionExpression asPositionExpression() throws ClassCastException {
        return this;
    }
}
