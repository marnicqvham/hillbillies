package hillbillies.model.expression.position;

import hillbillies.model.Position;
import hillbillies.model.Task;
import hillbillies.part3.programs.SourceLocation;

/**
 * Created by robin on 20/05/16.
 */
public class VariablePositionExpression extends PositionExpression {
    public final String key;
    public VariablePositionExpression(SourceLocation sourceLocation, String key) {
        super(sourceLocation);
        this.key = key;
    }

    @Override
    public Position getValue(Task task) {
        return ((PositionExpression)task.getVariable(key)).getValue(task);
    }

    @Override
    public String toString(Task task) {
        return getValue(task).toString();
    }
}
