package hillbillies.model.expression.BooleanExpression;

import hillbillies.model.Task;
import hillbillies.part3.programs.SourceLocation;

/**
 * Created by robin on 20/05/16.
 */
public class VariableBooleanExpression extends BooleanExpression {
    public final String key;
    public VariableBooleanExpression(SourceLocation sourceLocation, String key) {
        super(sourceLocation);
        this.key = key;
    }

    @Override
    public Boolean getValue(Task task) {
        return ((BooleanExpression)task.getVariable(key)).getValue(task);
    }
}
