package hillbillies.model.expression.BooleanExpression;

import hillbillies.model.Task;
import hillbillies.model.expression.Expression;
import hillbillies.model.expression.position.PositionExpression;
import hillbillies.part3.programs.SourceLocation;
import ogp.framework.util.ModelException;

/**
 * Created by marnicq van ham on 12/05/2016.
 */
public class IsSolidExpression extends BooleanExpression {
    public final PositionExpression position;
    public IsSolidExpression(Expression position, SourceLocation sourceLocation) {
        super(sourceLocation);
        this.position = position.asPositionExpression();
    }

    @Override
    public Boolean getValue(Task task) {
        try {
            return !position.getValue(task).isPassable();
        }catch (ModelException e) {
            //// FIXME: 16/05/16 
            return false;
        }
    }
}