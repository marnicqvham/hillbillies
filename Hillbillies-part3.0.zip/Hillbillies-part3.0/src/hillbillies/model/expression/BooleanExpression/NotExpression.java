package hillbillies.model.expression.BooleanExpression;

import hillbillies.model.Task;
import hillbillies.model.expression.Expression;
import hillbillies.part3.programs.SourceLocation;

/**
 * Created by marnicq van ham on 12/05/2016.
 */
public class NotExpression extends BooleanExpression {
    public final Expression<Boolean> expression;
    public NotExpression(Expression expression, SourceLocation sourceLocation) {
        super(sourceLocation);
        this.expression = expression.asBooleanExpression();
    }

    @Override
    public Boolean getValue(Task task) {
        return !expression.getValue(task);
    }
}
