package hillbillies.model.expression.BooleanExpression;

import hillbillies.model.Task;
import hillbillies.part3.programs.SourceLocation;

/**
 * Created by marnicq van ham on 12/05/2016.
 */
public class FalseExpression extends BooleanExpression {
    public FalseExpression(SourceLocation sourceLocation){
        super(sourceLocation);
    }

    public Boolean getValue(Task task) {
        return false;
    }
}
