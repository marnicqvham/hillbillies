package hillbillies.model.expression.BooleanExpression;

import hillbillies.model.Task;
import hillbillies.model.expression.Expression;
import hillbillies.part3.programs.SourceLocation;

/**
 * Created by marnicq van ham on 12/05/2016.
 */
public class OrExpression extends BooleanExpression {
    public final BooleanExpression left;
    public final BooleanExpression right;

    public OrExpression(Expression left, Expression right, SourceLocation sourceLocation) {
        super(sourceLocation);
        this.left = left.asBooleanExpression();
        this.right = right.asBooleanExpression();
    }

    @Override
    public Boolean getValue(Task task) {
        return left.getValue(task) || right.getValue(task);
    }
}
