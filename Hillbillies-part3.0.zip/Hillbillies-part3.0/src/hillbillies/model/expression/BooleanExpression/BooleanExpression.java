package hillbillies.model.expression.BooleanExpression;

import hillbillies.model.Task;
import hillbillies.model.expression.Expression;
import hillbillies.part3.programs.SourceLocation;

/**
 * Created by robin on 19/05/16.
 */
public abstract class BooleanExpression extends Expression<Boolean> {
    public BooleanExpression(SourceLocation sourceLocation){
        super(sourceLocation);
    }

    @Override
    public String toString(Task task) {
        if (getValue(task)){
            return "true";
        }else{
            return "false";
        }
    }

    @Override
    public BooleanExpression asBooleanExpression() throws ClassCastException {
        return this;
    }
}
