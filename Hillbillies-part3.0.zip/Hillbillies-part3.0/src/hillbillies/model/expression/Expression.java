package hillbillies.model.expression;

import hillbillies.model.Task;
import hillbillies.model.expression.BooleanExpression.BooleanExpression;
import hillbillies.model.expression.position.PositionExpression;
import hillbillies.model.expression.position.Unit.UnitExpression;
import hillbillies.part3.programs.SourceLocation;

/**
 * Created by robin on 11/05/16.
 * @param <T> return type of the expression
 */
public abstract class Expression<T> {
    public final SourceLocation sourceLocation;
    public Expression(SourceLocation sourceLocation) {
        this.sourceLocation = sourceLocation;
    }

    public abstract T getValue(Task task);

    public abstract String toString(Task task);

    public BooleanExpression asBooleanExpression() throws ClassCastException {
        throw new ClassCastException();
    }

    public UnitExpression asUnitExpression() throws ClassCastException {
        throw new ClassCastException();
    }

    public PositionExpression asPositionExpression() throws ClassCastException {
        throw new ClassCastException();
    }
}
