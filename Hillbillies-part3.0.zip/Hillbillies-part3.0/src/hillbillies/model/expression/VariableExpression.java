package hillbillies.model.expression;

import hillbillies.model.Task;
import hillbillies.model.expression.BooleanExpression.BooleanExpression;
import hillbillies.model.expression.BooleanExpression.VariableBooleanExpression;
import hillbillies.model.expression.position.PositionExpression;
import hillbillies.model.expression.position.Unit.UnitExpression;
import hillbillies.model.expression.position.Unit.VariableUnitExpression;
import hillbillies.model.expression.position.VariablePositionExpression;
import hillbillies.part3.programs.SourceLocation;

/**
 * Created by robin on 20/05/16.
 */
public class VariableExpression extends Expression {
    public final String key;
    public VariableExpression(SourceLocation sourceLocation, String key) {
        super(sourceLocation);
        this.key = key;
    }

    @Override
    public Object getValue(Task task) {
        return get(task).getValue(task);
    }

    private Expression get(Task task){
        return task.getVariable(key);
    }

    @Override
    public String toString(Task task) {
        return get(task).toString(task);
    }

    public BooleanExpression asBooleanExpression() throws ClassCastException {
        return new VariableBooleanExpression(sourceLocation, key);
    }

    public UnitExpression asUnitExpression() throws ClassCastException {
        return new VariableUnitExpression(sourceLocation, key);
    }

    public PositionExpression asPositionExpression() throws ClassCastException {
        return new VariablePositionExpression(sourceLocation, key);
    }

}
