package hillbillies.model;

import be.kuleuven.cs.som.annotate.Basic;
import be.kuleuven.cs.som.annotate.Raw;
import be.kuleuven.cs.som.annotate.Value;
import hillbillies.Util.Util;
import ogp.framework.util.ModelException;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

/**
 * Created by Robin on 22/02/2016.
 * @invar isValid
 */
@Value
public class Position {
    private double[] position;
    private World world;

    public Position(int[] position, World world){
        this(new double[] {
                position[0] + 0.5,
                position[1] + 0.5,
                position[2] + 0.5
        }, world);
    }

    public Position(double[] position, World world){
        this.world = world;
        if (!isValidPosition(position)){
            throw new IllegalArgumentException("Invalid position");
        }else{
            this.position = position;
        }
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Position position1 = (Position) o;

        if (!Arrays.equals(getPosAsInt(), position1.getPosAsInt())) return false;
        return world != null ? world.equals(position1.world) : position1.world == null;

    }

    @Override
    public int hashCode() {
        int result = Arrays.hashCode(getPosAsInt());
        result = 31 * result + (world != null ? world.hashCode() : 0);
        return result;
    }

    /**
     * @return (%f, %f, %f)", position[0], position[1], position[2]
     */
    public String toString(){
        return String.format("(%f, %f, %f)", position[0], position[1], position[2]);
    }

    /**
     * @param targetPos
     * @return The distance to this position. The absolute value of the difference between the positions
     */
    public double distanceTo(Position targetPos){
        double[] target = targetPos.getPosAsDouble();
        return Math.abs(target[0]-position[0])+
                Math.abs(target[1]-position[1])+
                Math.abs(target[2]-position[2]);
    }

    /**
      * @return a position with a lower z coordinate, if z=0 this will be returned
     */
    public Position getLower(){
        if (position[2]==00){
            return this;
        }else{
            return new Position(new int[] {(int)position[0], (int)position[1], (int)position[2]-1}, this.world);
        }
    }

    /**
     * Return the world of this position.
     * @return the world of this position.
     */
    @Basic @Raw
    public World getWorld(){
        return world;
    }

    /**
     * Return the position of this unit as double.
     * @return the position of this unit as double.
     */
    @Basic
    @Raw
    public double[] getPosAsDouble() {
        return position;
    }
    /**
     * Return the position of this unit as int.
     * @return the position of this unit as int.
     */
    @Basic @Raw
    public int[] getPosAsInt(){
        int[] intPos = new int[3];
        for (int i = 0; i< position.length; i++) {
            intPos[i] = (int)(position[i]);
        }
        return intPos;
    }

    /**
     * Check whether the given position is a valid position for
     * any unit as double.
     *
     * @param  position
     *         The position to check.
     * @return
     *       | result == 0 <= position < 50 && length = 3
    */
    public boolean isValidPosition(double[] position){
        int l = position.length;
        int[] nbCubes = world.getNbCubesXYZ();
        for (int i = 0; i < l; i++) {
            if (position[i] < 0 || position[i] > nbCubes[i]) {
                return false;
            }
        }
        return l == 3;
    }

    /**
     * Check whether the given position is a valid position for
     * any unit as int.
     *
     * @param  position
     *         The position to check.
     * @return
     *       | result == 0 <= position < 50 && length = 3
     */
    public boolean isValidPosition(int[] position){
        double[] doublePos = new double[3];
        for (int i = 0; i < position.length; i++){
            doublePos[i] = position[i];
        }
        return isValidPosition(doublePos);
    }

    /**
     * Prints the position.
     */
    public void print(){
        System.out.format("x: %.1f, y: %.1f, z: %.1f\n", position[0], position[1], position[2]);
    }
    /**
     * Check whether the given firstposition is adjacent to the secondposition for
     * any new position as doubles.
     *
     * @param  firstPos
     *         The position to check.
     * @param  secondPos
     *         The position to check.
     * @return
     *       | result == isAdjacentTo(firstPos.getPosAsInt(), secondPos.getPosAsInt())
    */
    public static boolean isAdjacentTo(Position firstPos, Position secondPos){
        return isAdjacentTo(firstPos.getPosAsInt(), secondPos.getPosAsInt());
    }
    /**
     * Check whether the given otherPosition is adjacent to the position for
     * any new position.
     *
     * @param  otherPosition
     *         The position to check.
     * @return
     *       | result == isAdjacentTo(this.getPosAsInt(), otherPosition.getPosAsInt())
     */
    public boolean isAdjacentTo(Position otherPosition){
        return isAdjacentTo(this.getPosAsInt(), otherPosition.getPosAsInt());
    }
    /**
     * Check whether the given firstposition is adjacent to the secondposition for
     * any new position as ints.
     *
     * @param  firstPos
     *         The position to check.
     * @param  secondPos
     *         The position to check.
     * @return
     *       | result == true if firstPost and secondPos is adjacent
     */
    public static boolean isAdjacentTo(int[] firstPos, int[] secondPos){
        int dif;
        for (int i=0; i<firstPos.length; i++){
            dif = firstPos[i] - secondPos[i];
            if (!(dif==0 || dif==-1 || dif==1)){
                return false;
            }
        }
        return !(Util.isSameArray(firstPos, secondPos));
    }

    /**
     * Return A list of all valid standable Positions next to this position.
     * @return A list of neighbouring positions with the same z, an were isValidPosition(position) && isStandabel() == true;
     */
     @Basic @Raw
    public Position[] getValidStandableNeighbours(){
        ArrayList<Position> neighbours = new ArrayList<Position>();
        Position pos;
        int[] curPos = getPosAsInt();
        for (int dx=-1; dx<=1; dx++){
            for (int dy=-1; dy<= 1; dy++){
                for (int dz=-1; dz<=1; dz++) {
                    try {
                        pos = new Position(new int[]{curPos[0] + dx, curPos[1] + dy, curPos[2] + dz}, world);
                        if (pos.isStandable()) {
                            neighbours.add(pos);
                        }
                    } catch (IllegalArgumentException e) {
                        //do nothing
                    }
                }
            }
        }
        return neighbours.toArray(new Position[neighbours.size()]);
    }
    public Position[] getNeighbours(){
        ArrayList<Position> neighbours = new ArrayList<Position>();
        Position pos;
        int[] curPos = getPosAsInt();
        for (int dx=-1; dx<=1; dx++){
            for (int dy=-1; dy<= 1; dy++){
                for (int dz=-1; dz<=1; dz++) {
                    try {
                        pos = new Position(new int[]{curPos[0] + dx, curPos[1] + dy, curPos[2] + dz}, world);
                        neighbours.add(pos);
                    } catch (IllegalArgumentException e) {
                        //do nothing
                    }
                }
            }
        }
        return neighbours.toArray(new Position[neighbours.size()]);
    }
    public boolean isPassable()throws ModelException{
        return (world.getCubeType((int)position[0], (int)position[1], (int)position[2]) == 0);
    }

    /**
     * Checks if the cube below this position is solid.
     * @return If the cube below is solid.
     */
    public boolean isStandable(){
        try{
            return (isPassable() &&
                    !(world.getCubeType((int)position[0], (int)position[1], (int)position[2]-1) == 0));
        }catch (ModelException e){
            return false;
        }
    }
    /**
     * Return the cubetype of this cube.
     * @return the cubetype of this cube.
     */
     @Basic @Raw
    public int getCubeType() throws ModelException{
        return world.getCubeType((int)position[0], (int)position[1], (int)position[2]);
    }

    public int getAmountOfPositionsTo(Position target){
        int[] t = target.getPosAsInt();
        int[] s = getPosAsInt();
        return (Math.abs(t[0]-s[0])+Math.abs(t[1]-s[1])+Math.abs(t[2]-s[2]));
    }

    /**
     * @return worldObject at this position if there is one, else null
     */
    public Set<WorldObject>getObjectHere(){
        Set<WorldObject> logAndBoulder = new HashSet<>();
        for (WorldObject log :world.getLogs()) {
            if(Util.isSameArray(log.getPosAsInt(), getPosAsInt())) {
                logAndBoulder.add(log);
            }
        }
        for (WorldObject boulder :world.getBoulders()) {
            if(Util.isSameArray(boulder.getPosAsInt(), getPosAsInt())) {
                logAndBoulder.add(boulder);
            }
        }
        return logAndBoulder;
    }
}

