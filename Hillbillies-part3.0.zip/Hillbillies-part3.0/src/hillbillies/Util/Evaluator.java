package hillbillies.Util;

/**
 * Created by robin on 20/05/16.
 */
public class Evaluator<T, E> {
}
