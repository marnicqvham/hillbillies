package hillbillies.Util;

import hillbillies.model.Position;
import ogp.framework.util.ModelException;

/**
 * Created by robin on 20/05/16.
 */
public class WorkshopFinder implements Finder {
    @Override
    public boolean evaluate(Position position) {
        try {
            return position.getLower().getCubeType() == 3;
        }catch (ModelException e){
            return false;
        }
    }

    public Position find(Position here) {
        return Util.find(this, here);
    }
}
