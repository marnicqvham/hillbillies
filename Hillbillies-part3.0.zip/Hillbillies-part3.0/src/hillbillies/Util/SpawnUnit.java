package hillbillies.Util;

import hillbillies.model.Position;
import hillbillies.model.Unit;
import hillbillies.model.Faction;
import hillbillies.model.World;
import ogp.framework.util.ModelException;

import java.util.ArrayList;

/**
 * Created by marnicq van ham on 14/03/2016.
 */
public class SpawnUnit {
    public static Unit spawnUnit(World world, boolean enableDefaultBehavior) throws ModelException {
        Faction faction = world.getFactions()[0];
        if (faction.isFull()){
            throw new ModelException("The faction is full");
        }
        Unit unit;
        String name = "Unit";
        Position initialPosition = randomStandablePosition(world);
        int weight = (int)(Math.random()*75 +25),
                agility = (int)(Math.random()*75 +25),
                strength =(int)(Math.random()*75 +25),
                toughness = (int)(Math.random()*75 +25);

        unit = new Unit(name, initialPosition, weight, agility, strength, toughness, enableDefaultBehavior, world, faction);
        faction.addUnit(unit);
        return unit;
    }
    private static Position randomStandablePosition(World world){
        ArrayList<Position> positions = new ArrayList<>();
        Position pos;
        for (int x = 0; x < world.getNbCubesX(); x++) {
            for (int y = 0; y < world.getNbCubesY(); y++) {
                for (int z = 0; z < world.getNbCubesZ(); z++) {
                    try {
                        pos = new Position(new int[] {x, y, z}, world);
                        if (pos.isStandable()){
                            positions.add(pos);
                        }
                    }catch (IllegalArgumentException e) {
                        //do nothing
                    }
                }

            }

        }
        return positions.get((int)(Math.random()*positions.size()));
    }
}
