package hillbillies.Util;

import hillbillies.model.Boulder;
import hillbillies.model.Log;
import hillbillies.model.Position;
import hillbillies.model.WorldObject;

import java.util.*;

/**
 * Created by robin on 8/04/16.
 */
public class Util {

    public static Position find(Finder finder, Position start){
        Stack<Position> toCheck = new Stack<>();
        Set<Position> checked = new HashSet<>();
        toCheck.add(start);
        Position current;
        while(!toCheck.isEmpty()){
            current = toCheck.pop();
            if (finder.evaluate(current)){
                return current;
            }
            checked.add(current);
            toCheck.addAll(Arrays.asList(current.getValidStandableNeighbours()));
            toCheck.removeAll(checked);
        }
        return null;
    }


    /**
     * check weather the given arrays are the same
     * @param arrayOne
     * @param arrayTwo
     * @return true if the arrays are the same
     */
    public static boolean isSameArray(int[] arrayOne, int[] arrayTwo){
        for (int i = 0; i < arrayOne.length; i++) {
            if (arrayOne[i] != arrayTwo[i]){
                return false;
            }
        }
        return true;
    }

    /**
     * Check whether the given array is the same to the other array as double.
     *
     * @param  arrayOne
     *         The array to check.
     * @param  arrayTwo
     *         The array to check.
     * @return
     *       | result == true if same array
     */
    public static boolean isSameArray(double[] arrayOne, double[] arrayTwo){
        for (int i = 0; i < arrayOne.length; i++) {
            if (arrayOne[i] != arrayTwo[i]){
                return false;
            }
        }
        return true;
    }

    /**
     * Cast each element from a double to an integer.
     * @param array
     * @return result[x] = (int)array[x]
     */
    public static int[] doubleArrayToInt(double[] array){
        int[] newArray = new int[array.length];
        for (int i = 0; i < array.length; i++) {
            newArray[i] = (int)array[i];
        }
        return newArray;
    }

    /**
     * Has a chance to return true.
     * @param probability
     * @return true if Math.random()<= probability else false.
     */
    public static boolean happensWithProbability(double probability){
        double rand = Math.random();
        return rand <= probability;
    }

    public static List<WorldObject> getBoulderAndLogInSet(Set<WorldObject> object){
        List<WorldObject> objects = new LinkedList<>();
        for (WorldObject worldobject: object) {
            if (object.getClass().equals(Boulder.class)){
                objects.add(worldobject);
                break;
            }
        }
        for (WorldObject worldobject: object) {
            if (object.getClass().equals(Log.class)){
                objects.add(worldobject);
                break;
            }
        }
        return objects;
    }
}
