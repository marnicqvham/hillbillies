package hillbillies.Util;

import hillbillies.model.Position;
import hillbillies.model.Unit;

import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * Created by robin on 20/05/16.
 */
public class UnitFinder implements Finder {
    Set<Unit> items;

    @Override
    public boolean evaluate(Position position) {
        for (Unit unit :
                items) {
            if (unit.getPosition().equals(position)) {
                return true;
            }
        }
        return false;
    }

    public Unit find(Position here, Set<Unit> items) {
        this.items = items;
        return getObject(Util.find(this, here));
    }

    public Unit getObject(Position position) {
        List<Unit> units = items.stream().filter((s) -> s.getPosition().equals(position)).collect(Collectors.toList());
        if (units.isEmpty()){
            return null;
        }else{
            return units.get(0);
        }
    }
}
