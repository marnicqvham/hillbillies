package hillbillies.Util;

import hillbillies.model.statement.BreakStatement;
import hillbillies.model.statement.Statement;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Created by marnicq van ham on 20/05/2016.
 */

public class StatementTree {
    private Node rootStatement;

    public List<Node> getBreakstatements() {
        return breakstatements;
    }

    private List<Node> breakstatements;


    public StatementTree(Statement statement) {
        breakstatements = new ArrayList<>();
        rootStatement = new Node(statement, statement.allStatements(),null);
    }

    public class Node {
        public final Statement statement;
        protected List<Node> children;
        private Node parent;
        public Node(Statement statement, List<Statement> statementChildren, Node parent){
            if(statementChildren == null){
                statementChildren = new ArrayList<>();
            }
            statementChildren.removeAll(Collections.singleton(null));
            if (statement instanceof BreakStatement){
                breakstatements.add(this);
            }
            this.children = new ArrayList<>();
            for (Statement child: statementChildren) {
                children.add(new Node(child,child.allStatements(),this));
            }
            this.statement = statement;
            this.parent = parent;
        }

        public List<Node> getChildren() {
            return children;
        }

        public Node getParent() {
            return parent;
        }
    }
}