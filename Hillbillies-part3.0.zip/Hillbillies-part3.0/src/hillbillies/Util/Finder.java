package hillbillies.Util;

import hillbillies.model.Position;

/**
 * Created by robin on 20/05/16.
 */
public interface Finder {
    boolean evaluate(Position position);
}
