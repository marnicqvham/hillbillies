package hillbillies.Util;

import hillbillies.model.Position;

/**
 * Created by robin on 20/05/16.
 */
public class RndFinder implements Finder{
    @Override
    public boolean evaluate(Position position) {
        return Util.happensWithProbability(0.1);
    }

    public Position find(Position here) {
        Position result = Util.find(this, here);
        if (result != null){
            return result;
        }else{
            return here;
        }
    }
}
