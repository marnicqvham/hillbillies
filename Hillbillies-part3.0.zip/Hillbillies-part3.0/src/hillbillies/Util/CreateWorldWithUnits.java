package hillbillies.Util;

import hillbillies.model.World;
import hillbillies.part2.facade.Facade;
import hillbillies.part2.internal.map.CubeType;
import hillbillies.part2.internal.map.GameMap;
import hillbillies.part2.internal.map.GameMapReader;
import hillbillies.part2.listener.TerrainChangeListener;
import ogp.framework.util.ModelException;

import java.io.FileNotFoundException;
import java.util.HashSet;
import java.util.Set;

/**
 * Created by marnicq van ham on 19/05/2016.
 */
public class CreateWorldWithUnits {
    private static final Set<TerrainChangeListener> listeners = new HashSet<>();
    private static TerrainChangeListener modelListener = new TerrainChangeListener() {

        @Override
        public void notifyTerrainChanged(int x, int y, int z) {
            for (TerrainChangeListener listener : new HashSet<>(listeners)) {
                listener.notifyTerrainChanged(x, y, z);
            }
        }
    };
    public static World createWorldWithUnits() throws FileNotFoundException, ModelException {
        GameMap map = null;
        GameMapReader gameMapReader = new GameMapReader();
        map = gameMapReader.readFromFile("C:\\Users\\marnicq van ham\\ogp\\Hillbillies\\src-provided\\resources\\15x15x15.wrld");
        int[][][] types = new int[map.getNbTilesX()][map.getNbTilesY()][map.getNbTilesZ()];

        for (int x = 0; x < types.length; x++) {
            for (int y = 0; y < types[x].length; y++) {
                for (int z = 0; z < types[x][y].length; z++) {
                    CubeType type = map.getTypeAt(x, y, z);
                    types[x][y][z] = type.getByteValue();
                }
            }
        }
        World world = new World(types,modelListener);
        Facade facade = new Facade();
        facade.spawnUnit(world,false);
        return world;
    }
}
