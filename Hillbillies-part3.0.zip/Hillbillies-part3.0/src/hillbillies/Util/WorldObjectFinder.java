package hillbillies.Util;

import hillbillies.model.Position;
import hillbillies.model.WorldObject;

import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * Created by robin on 20/05/16.
 */
public class WorldObjectFinder<T extends WorldObject> implements Finder {
    Set<T> items;

    @Override
    public boolean evaluate(Position position) {
        for (T item :
                items) {
            if (item.getPosition().equals(position)) {
                return true;
            }
        }
        return false;
    }

    public Position find(Position here, Set<T> items) {
        this.items = items;
        return Util.find(this, here);
    }

    public T getObject(Position position) {
        List<T> objects = items.stream().filter((s) -> s.getPosition().equals(position)).collect(Collectors.toList());
        if (objects.isEmpty()){
            return null;
        }else{
            return objects.get(0);
        }
    }
}
